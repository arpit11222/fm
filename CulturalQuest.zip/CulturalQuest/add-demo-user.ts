import { hashSync } from 'bcrypt';
import { db } from './server/db';
import { users } from './shared/schema';

async function addDemoUser() {
  try {
    // Demo user credentials
    const demoUser = {
      username: "demo",
      password: hashSync("password123", 10),
      email: "demo@finmate.com",
      displayName: "Demo User",
      level: 5,
      experience: 250,
      streak: 7,
      lastLogin: new Date(),
      createdAt: new Date()
    };

    // Insert the user
    const insertedUser = await db.insert(users).values(demoUser).onConflictDoNothing().returning();
    
    if (insertedUser.length > 0) {
      console.log('Demo user created successfully!');
    } else {
      console.log('Demo user already exists.');
    }
    
    console.log('You can log in with:');
    console.log('Username: demo');
    console.log('Password: password123');
  } catch (error) {
    console.error('Error creating demo user:', error);
  } finally {
    process.exit(0);
  }
}

addDemoUser();