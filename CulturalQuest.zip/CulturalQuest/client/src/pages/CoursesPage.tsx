import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { TrendingUp, DollarSign, Shield, Zap, Book } from "lucide-react";
import { CourseCard } from "@/components/CourseCard";
import { SkillTree } from "@/components/SkillTree";
import { Button } from "@/components/ui/button";

export default function CoursesPage() {
  const { data: courses, isLoading } = useQuery({
    queryKey: ["/api/courses"],
  });

  const { data: userProgress, isLoading: isProgressLoading } = useQuery({
    queryKey: ["/api/user/progress"],
  });

  if (isLoading || isProgressLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="loader">Loading...</div>
      </div>
    );
  }

  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <div className="bg-black py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                Financial Learning <span className="text-primary">Courses</span>
              </h1>
              <p className="text-lg text-neutral-400 mb-8">
                Explore our comprehensive curriculum designed to build your financial literacy from the ground up.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
      
      {/* Learning Path Visualization */}
      <div className="py-10 border-t border-zinc-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center mb-10">
            <div className="lg:w-1/3 mb-8 lg:mb-0 lg:pr-12">
              <h2 className="text-2xl font-bold mb-4">Your Learning Path</h2>
              <p className="text-neutral-400 mb-6">
                Follow our structured learning path to master personal finance step by step. Each course builds upon previous knowledge to create a solid financial foundation.
              </p>
              <div className="flex flex-col gap-4">
                <div className="flex items-center">
                  <div className="h-8 w-8 rounded-full bg-green-500 flex items-center justify-center mr-4">
                    <DollarSign className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-medium">Personal Finance</h3>
                    <p className="text-xs text-neutral-400">Budgeting, Saving, Debt Management</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center mr-4">
                    <TrendingUp className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-medium">Investing</h3>
                    <p className="text-xs text-neutral-400">Stocks, Bonds, Real Estate</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="h-8 w-8 rounded-full bg-amber-500 flex items-center justify-center mr-4">
                    <Shield className="h-4 w-4 text-white" />
                  </div>
                  <div>
                    <h3 className="font-medium">Advanced Topics</h3>
                    <p className="text-xs text-neutral-400">Tax Planning, Retirement, Estate Planning</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="lg:w-2/3 bg-zinc-900/20 rounded-xl border border-zinc-800 p-6">
              <h3 className="text-lg font-medium mb-6 text-center">Interactive Skill Tree</h3>
              {userProgress ? (
                <div className="relative">
                  <div className="skill-tree-container">
                    <div className="skill-tree-wrapper overflow-x-auto">
                      {courses && courses.length > 0 ? (
                        <div className="min-h-[400px]">
                          <SkillTree courses={courses} progress={userProgress} />
                        </div>
                      ) : (
                        <div className="flex items-center justify-center h-64">
                          <p className="text-neutral-400">Loading skill tree...</p>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center h-64">
                  <div className="text-center">
                    <div className="inline-flex items-center justify-center p-3 bg-zinc-800 rounded-full mb-4">
                      <Book className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-medium mb-2">Start Your Learning Journey</h3>
                    <p className="text-neutral-400 mb-6">Complete courses to visualize your progress in the skill tree.</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Courses Categories */}
      <div className="border-t border-zinc-800 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-4 text-center">
            <h3 className="text-lg font-medium">Filter by Category</h3>
          </div>
          <div className="flex flex-wrap justify-center gap-3">
            <Button
              variant="outline"
              className="bg-primary/10 border-primary/20 text-primary hover:bg-primary/20 transition-all duration-300 transform hover:-translate-y-1"
              onClick={() => window.location.hash = "all"}
            >
              All Courses
            </Button>
            <Button
              variant="outline"
              className="bg-transparent border-zinc-800 hover:bg-zinc-900 transition-all duration-300 transform hover:-translate-y-1"
              onClick={() => window.location.hash = "personal-finance"}
            >
              <DollarSign className="h-4 w-4 mr-2" /> Personal Finance
            </Button>
            <Button
              variant="outline"
              className="bg-transparent border-zinc-800 hover:bg-zinc-900 transition-all duration-300 transform hover:-translate-y-1"
              onClick={() => window.location.hash = "investing"}
            >
              <TrendingUp className="h-4 w-4 mr-2" /> Investing
            </Button>
            <Button
              variant="outline"
              className="bg-transparent border-zinc-800 hover:bg-zinc-900 transition-all duration-300 transform hover:-translate-y-1"
              onClick={() => window.location.hash = "insurance"}
            >
              <Shield className="h-4 w-4 mr-2" /> Insurance
            </Button>
            <Button
              variant="outline"
              className="bg-transparent border-zinc-800 hover:bg-zinc-900 transition-all duration-300 transform hover:-translate-y-1"
              onClick={() => window.location.hash = "advanced"}
            >
              <Zap className="h-4 w-4 mr-2" /> Advanced Topics
            </Button>
          </div>
        </div>
      </div>

      {/* Featured Courses */}
      <div className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-2">Popular Courses</h2>
            <p className="text-neutral-400">Start with these highly-rated courses</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses && courses.length > 0 ? (
              courses
                .filter(course => course.category === "featured")
                .map(course => {
                  const progress = userProgress?.find(p => p.courseId === course.id)?.progress || 0;
                  return <CourseCard key={course.id} course={course} progress={progress} />;
                })
            ) : (
              <div className="col-span-3 py-10 text-center">
                <div className="inline-flex items-center justify-center p-3 bg-zinc-900 rounded-full mb-4">
                  <Book className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-medium mb-2">No courses available yet</h3>
                <p className="text-neutral-400 mb-6">We're working on adding great financial courses for you.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Course Categories */}
      <div className="py-12 bg-zinc-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-2">Personal Finance</h2>
            <p className="text-neutral-400">Master the basics of managing your money</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses && courses.length > 0 ? (
              courses
                .filter(course => course.category === "personal finance")
                .map(course => {
                  const progress = userProgress?.find(p => p.courseId === course.id)?.progress || 0;
                  return <CourseCard key={course.id} course={course} progress={progress} />;
                })
            ) : (
              <div className="col-span-3 py-10 text-center">
                <p className="text-neutral-400">No personal finance courses available yet.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Investing Courses */}
      <div className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-2">Investing</h2>
            <p className="text-neutral-400">Learn how to grow your wealth effectively</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses && courses.length > 0 ? (
              courses
                .filter(course => course.category === "investing")
                .map(course => {
                  const progress = userProgress?.find(p => p.courseId === course.id)?.progress || 0;
                  return <CourseCard key={course.id} course={course} progress={progress} />;
                })
            ) : (
              <div className="col-span-3 py-10 text-center">
                <p className="text-neutral-400">No investing courses available yet.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Advanced Topics */}
      <div className="py-12 bg-zinc-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-2">Advanced Topics</h2>
            <p className="text-neutral-400">For those ready to take their financial knowledge to the next level</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {courses && courses.length > 0 ? (
              courses
                .filter(course => course.category === "advanced")
                .map(course => {
                  const progress = userProgress?.find(p => p.courseId === course.id)?.progress || 0;
                  return <CourseCard key={course.id} course={course} progress={progress} />;
                })
            ) : (
              <div className="col-span-3 py-10 text-center">
                <p className="text-neutral-400">No advanced courses available yet.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}