import { motion } from "framer-motion";
import { 
  BookOpen, 
  FileText, 
  HelpCircle, 
  Info, 
  Calculator, 
  Search, 
  BarChart2, 
  DollarSign,
  Newspaper,
  ExternalLink,
  Download,
  BookMarked,
  ArrowLeft,
  ChevronRight
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useLocation, useRoute } from "wouter";
import { useState, useEffect } from "react";
import { CompoundInterestCalculator } from "@/components/calculators/CompoundInterestCalculator";
import { BudgetPlanner } from "@/components/calculators/BudgetPlanner";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";

// Function to open external links safely
const openExternalLink = (url: string) => {
  const newWindow = window.open(url, '_blank', 'noopener,noreferrer');
  if (newWindow) newWindow.opener = null;
};

export default function ResourcesPage() {
  const [location, setLocation] = useLocation();
  const [, params] = useRoute("/resources/:tab?");
  const [activeTab, setActiveTab] = useState("guides");
  
  // For calculator viewing
  const [showCompoundCalculator, setShowCompoundCalculator] = useState(false);
  const [showBudgetPlanner, setShowBudgetPlanner] = useState(false);
  
  // For guide viewing
  const [selectedGuide, setSelectedGuide] = useState<string | null>(null);
  
  // Update active tab based on route parameter
  useEffect(() => {
    const currentTab = params?.tab;
    if (currentTab) {
      if (["guides", "tools", "glossary", "faq", "news"].includes(currentTab)) {
        setActiveTab(currentTab);
      }
    } else {
      // Default to guides if no tab specified
      setActiveTab("guides");
    }
    
    // Reset calculators and dialogs when changing tabs
    setShowCompoundCalculator(false);
    setShowBudgetPlanner(false);
    setSelectedGuide(null);
  }, [params?.tab]);
  
  // Handle tab change
  const handleTabChange = (value: string) => {
    setActiveTab(value);
    setLocation(`/resources/${value}`);
    
    // Reset calculators and dialogs when changing tabs
    setShowCompoundCalculator(false);
    setShowBudgetPlanner(false);
    setSelectedGuide(null);
  };
  
  // Open a guide for reading
  const openGuide = (guideName: string) => {
    setSelectedGuide(guideName);
  };
  
  // Close the guide dialog
  const closeGuide = () => {
    setSelectedGuide(null);
  };
  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <div className="bg-black py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                Financial <span className="text-primary">Resources</span> Library
              </h1>
              <p className="text-lg text-neutral-400 mb-8">
                Access helpful guides, tools, and references to enhance your financial education journey.
              </p>
              <div className="relative max-w-xl mx-auto mb-10">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-500" />
                <Input 
                  type="text" 
                  placeholder="Search articles, guides, and resources..." 
                  className="pl-10 bg-zinc-900 border-zinc-800 h-12"
                />
                <Button className="absolute right-1 top-1/2 -translate-y-1/2 h-10" size="sm">
                  Search
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Resources Tabs */}
      <div className="py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
            <TabsList className="w-full grid grid-cols-2 md:grid-cols-5 h-auto p-1 bg-zinc-900 mb-8">
              <TabsTrigger value="guides" className="py-3 px-4 data-[state=active]:bg-primary/20">
                <BookOpen className="h-4 w-4 mr-2" />
                Guides
              </TabsTrigger>
              <TabsTrigger value="tools" className="py-3 px-4 data-[state=active]:bg-primary/20">
                <Calculator className="h-4 w-4 mr-2" />
                Tools
              </TabsTrigger>
              <TabsTrigger value="glossary" className="py-3 px-4 data-[state=active]:bg-primary/20">
                <BookMarked className="h-4 w-4 mr-2" />
                Glossary
              </TabsTrigger>
              <TabsTrigger value="faq" className="py-3 px-4 data-[state=active]:bg-primary/20">
                <HelpCircle className="h-4 w-4 mr-2" />
                FAQ
              </TabsTrigger>
              <TabsTrigger value="news" className="py-3 px-4 data-[state=active]:bg-primary/20">
                <Newspaper className="h-4 w-4 mr-2" />
                News
              </TabsTrigger>
            </TabsList>

            {/* Guides Tab */}
            <TabsContent value="guides" className="mt-0">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <Card className="bg-zinc-900 border-zinc-800 overflow-hidden">
                  <div className="h-40 bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
                    <BookOpen className="h-16 w-16 text-primary/70" />
                  </div>
                  <CardHeader className="pb-2">
                    <div className="flex gap-2 mb-2">
                      <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/20">
                        Beginner
                      </Badge>
                      <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                        Personal Finance
                      </Badge>
                    </div>
                    <CardTitle>Budgeting Basics</CardTitle>
                    <CardDescription>Learn the foundations of creating and maintaining a budget</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm text-neutral-400 space-y-1">
                      <li className="flex items-center gap-2">
                        <Info className="h-4 w-4 text-primary" /> The 50/30/20 rule explained
                      </li>
                      <li className="flex items-center gap-2">
                        <Info className="h-4 w-4 text-primary" /> Tracking expenses effectively
                      </li>
                      <li className="flex items-center gap-2">
                        <Info className="h-4 w-4 text-primary" /> Setting realistic financial goals
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      className="w-full" 
                      variant="outline"
                      onClick={() => openGuide("Budgeting Basics")}
                    >
                      Read Guide
                    </Button>
                  </CardFooter>
                </Card>

                <Card className="bg-zinc-900 border-zinc-800 overflow-hidden">
                  <div className="h-40 bg-gradient-to-br from-amber-500/20 to-amber-500/5 flex items-center justify-center">
                    <BarChart2 className="h-16 w-16 text-amber-400/70" />
                  </div>
                  <CardHeader className="pb-2">
                    <div className="flex gap-2 mb-2">
                      <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/20">
                        Intermediate
                      </Badge>
                      <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                        Investing
                      </Badge>
                    </div>
                    <CardTitle>Stock Market Fundamentals</CardTitle>
                    <CardDescription>Understanding how to invest in stocks and equity markets</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm text-neutral-400 space-y-1">
                      <li className="flex items-center gap-2">
                        <Info className="h-4 w-4 text-amber-400" /> Market indices and what they mean
                      </li>
                      <li className="flex items-center gap-2">
                        <Info className="h-4 w-4 text-amber-400" /> Evaluating company fundamentals
                      </li>
                      <li className="flex items-center gap-2">
                        <Info className="h-4 w-4 text-amber-400" /> Building a diversified portfolio
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      className="w-full" 
                      variant="outline"
                      onClick={() => openGuide("Stock Market Fundamentals")}
                    >
                      Read Guide
                    </Button>
                  </CardFooter>
                </Card>

                <Card className="bg-zinc-900 border-zinc-800 overflow-hidden">
                  <div className="h-40 bg-gradient-to-br from-green-500/20 to-green-500/5 flex items-center justify-center">
                    <DollarSign className="h-16 w-16 text-green-400/70" />
                  </div>
                  <CardHeader className="pb-2">
                    <div className="flex gap-2 mb-2">
                      <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/20">
                        Advanced
                      </Badge>
                      <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                        Retirement
                      </Badge>
                    </div>
                    <CardTitle>Retirement Planning</CardTitle>
                    <CardDescription>Strategies for securing your financial future</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="text-sm text-neutral-400 space-y-1">
                      <li className="flex items-center gap-2">
                        <Info className="h-4 w-4 text-green-400" /> Calculating retirement needs
                      </li>
                      <li className="flex items-center gap-2">
                        <Info className="h-4 w-4 text-green-400" /> Tax-advantaged account options
                      </li>
                      <li className="flex items-center gap-2">
                        <Info className="h-4 w-4 text-green-400" /> Creating retirement income streams
                      </li>
                    </ul>
                  </CardContent>
                  <CardFooter>
                    <Button 
                      className="w-full" 
                      variant="outline"
                      onClick={() => openGuide("Retirement Planning")}
                    >
                      Read Guide
                    </Button>
                  </CardFooter>
                </Card>
              </div>
              
              <div className="mt-8 text-center">
                <Button onClick={() => openExternalLink('https://www.investor.gov/introduction-investing/getting-started')}>
                  View All Guides
                </Button>
              </div>
              
              {/* Guide Content Dialogs */}
              <Dialog open={selectedGuide === "Budgeting Basics"} onOpenChange={closeGuide}>
                <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle className="text-2xl">Budgeting Basics</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 text-neutral-200">
                    <h2 className="text-xl font-semibold text-primary">Introduction to Budgeting</h2>
                    <p>
                      Budgeting is the foundation of financial stability. It involves creating a plan to spend your money 
                      deliberately, which allows you to determine in advance whether you will have enough money to do the things 
                      you need or would like to do.
                    </p>
                    
                    <h2 className="text-xl font-semibold text-primary">The 50/30/20 Rule Explained</h2>
                    <p>
                      The 50/30/20 rule is a simple budgeting framework that suggests allocating your after-tax income as follows:
                    </p>
                    <ul className="list-disc pl-5 space-y-2">
                      <li><strong>50% for needs:</strong> These are must-haves—housing, food, utilities, transportation, insurance, and minimum debt payments.</li>
                      <li><strong>30% for wants:</strong> These are non-essentials that enhance your life—dining out, entertainment, vacations, and hobbies.</li>
                      <li><strong>20% for savings and debt repayment:</strong> This category includes retirement contributions, emergency fund savings, and payments above the minimums on your debts.</li>
                    </ul>
                    
                    <h2 className="text-xl font-semibold text-primary">Tracking Expenses Effectively</h2>
                    <p>
                      Tracking where your money goes is crucial for maintaining a budget. Here are some effective methods:
                    </p>
                    <ul className="list-disc pl-5 space-y-2">
                      <li><strong>Use budgeting apps:</strong> Apps like Mint, YNAB, or Personal Capital can automatically categorize your transactions.</li>
                      <li><strong>Envelope system:</strong> Allocate cash for different expense categories in physical or digital envelopes.</li>
                      <li><strong>Regular review:</strong> Set aside time weekly to review your spending and adjust your budget as needed.</li>
                    </ul>
                    
                    <h2 className="text-xl font-semibold text-primary">Setting Realistic Financial Goals</h2>
                    <p>
                      Effective goals follow the SMART criteria—Specific, Measurable, Achievable, Relevant, and Time-bound:
                    </p>
                    <ul className="list-disc pl-5 space-y-2">
                      <li><strong>Short-term goals (under 1 year):</strong> Building an emergency fund, saving for a vacation, or paying off a small debt.</li>
                      <li><strong>Medium-term goals (1-5 years):</strong> Saving for a down payment on a home, paying off student loans, or funding education.</li>
                      <li><strong>Long-term goals (5+ years):</strong> Retirement planning, funding your children's college education, or achieving financial independence.</li>
                    </ul>
                    
                    <h2 className="text-xl font-semibold text-primary">Common Budgeting Mistakes to Avoid</h2>
                    <ul className="list-disc pl-5 space-y-2">
                      <li>Forgetting occasional expenses (car repairs, medical bills, gifts)</li>
                      <li>Setting unrealistic restrictions that are hard to maintain</li>
                      <li>Not adjusting your budget as your income or expenses change</li>
                      <li>Neglecting to plan for emergencies</li>
                      <li>Excluding small, frequent purchases that add up over time</li>
                    </ul>
                  </div>
                </DialogContent>
              </Dialog>
              
              <Dialog open={selectedGuide === "Stock Market Fundamentals"} onOpenChange={closeGuide}>
                <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle className="text-2xl">Stock Market Fundamentals</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 text-neutral-200">
                    <h2 className="text-xl font-semibold text-amber-400">Understanding the Stock Market</h2>
                    <p>
                      The stock market is a collection of exchanges where stocks (pieces of ownership in businesses) are bought and sold. 
                      Investing in stocks gives you the opportunity to participate in a company's success through increases in its stock 
                      price and through dividends.
                    </p>
                    
                    <h2 className="text-xl font-semibold text-amber-400">Market Indices and What They Mean</h2>
                    <p>
                      Stock market indices are measurements of sections of the stock market and are used to track market performance:
                    </p>
                    <ul className="list-disc pl-5 space-y-2">
                      <li><strong>S&P 500:</strong> Tracks the performance of 500 largest U.S. publicly traded companies</li>
                      <li><strong>Dow Jones Industrial Average (DJIA):</strong> Represents 30 large, established U.S. companies</li>
                      <li><strong>Nasdaq Composite:</strong> Heavily weighted toward technology companies</li>
                      <li><strong>Russell 2000:</strong> Measures the performance of 2,000 smaller U.S. companies</li>
                    </ul>
                    
                    <h2 className="text-xl font-semibold text-amber-400">Evaluating Company Fundamentals</h2>
                    <p>
                      When considering stock investments, evaluate these key metrics:
                    </p>
                    <ul className="list-disc pl-5 space-y-2">
                      <li><strong>Price-to-Earnings (P/E) Ratio:</strong> The price of a share divided by earnings per share, indicating how much investors are willing to pay for $1 of earnings</li>
                      <li><strong>Earnings Per Share (EPS):</strong> A company's profit divided by outstanding shares</li>
                      <li><strong>Dividend Yield:</strong> Annual dividends per share divided by price per share</li>
                      <li><strong>Return on Equity (ROE):</strong> Net income divided by shareholder equity, showing how efficiently a company uses investments to generate earnings</li>
                      <li><strong>Debt-to-Equity Ratio:</strong> Total liabilities divided by shareholder equity, indicating financial leverage</li>
                    </ul>
                    
                    <h2 className="text-xl font-semibold text-amber-400">Building a Diversified Portfolio</h2>
                    <p>
                      Diversification is key to managing risk in stock investing:
                    </p>
                    <ul className="list-disc pl-5 space-y-2">
                      <li><strong>Across sectors:</strong> Spread investments across different industries (technology, healthcare, energy, consumer goods, etc.)</li>
                      <li><strong>By company size:</strong> Include large-cap (established), mid-cap (growing), and small-cap (emerging) companies</li>
                      <li><strong>Geographic diversity:</strong> Consider both domestic and international stocks</li>
                      <li><strong>Asset allocation:</strong> Balance stocks with other assets like bonds, real estate, and cash based on your risk tolerance and time horizon</li>
                    </ul>
                  </div>
                </DialogContent>
              </Dialog>
              
              <Dialog open={selectedGuide === "Retirement Planning"} onOpenChange={closeGuide}>
                <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle className="text-2xl">Retirement Planning</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 text-neutral-200">
                    <h2 className="text-xl font-semibold text-green-400">Why Retirement Planning Matters</h2>
                    <p>
                      Retirement planning involves preparing financially for life after you stop working. With increasing life 
                      expectancy and changing pension systems, personal retirement planning is more important than ever to ensure 
                      financial security in your later years.
                    </p>
                    
                    <h2 className="text-xl font-semibold text-green-400">Calculating Retirement Needs</h2>
                    <p>
                      Determining how much to save for retirement involves several factors:
                    </p>
                    <ul className="list-disc pl-5 space-y-2">
                      <li><strong>Retirement lifestyle:</strong> Estimate your annual expenses in retirement (typically 70-80% of pre-retirement income)</li>
                      <li><strong>Life expectancy:</strong> Plan for a longer life than you might expect—many financial advisors recommend planning to age 90 or beyond</li>
                      <li><strong>Inflation:</strong> Account for rising costs over time (historically averaging 2-3% annually)</li>
                      <li><strong>Healthcare costs:</strong> Budget for increased medical expenses as you age</li>
                      <li><strong>The 4% rule:</strong> A common guideline suggesting you can withdraw 4% of your retirement savings annually without depleting your principal</li>
                    </ul>
                    
                    <h2 className="text-xl font-semibold text-green-400">Tax-Advantaged Account Options</h2>
                    <p>
                      These specialized accounts offer tax benefits to encourage retirement saving:
                    </p>
                    <ul className="list-disc pl-5 space-y-2">
                      <li><strong>401(k)/403(b) plans:</strong> Employer-sponsored plans with pre-tax contributions, often with employer matching</li>
                      <li><strong>Traditional IRA:</strong> Individual Retirement Account with tax-deductible contributions and tax-deferred growth</li>
                      <li><strong>Roth IRA:</strong> After-tax contributions with tax-free withdrawals in retirement</li>
                      <li><strong>SEP IRA and SIMPLE IRA:</strong> Retirement options for self-employed individuals and small business owners</li>
                      <li><strong>Health Savings Account (HSA):</strong> While primarily for healthcare expenses, can function as an additional retirement account after age 65</li>
                    </ul>
                    
                    <h2 className="text-xl font-semibold text-green-400">Creating Retirement Income Streams</h2>
                    <p>
                      Diversifying your retirement income sources helps manage risk:
                    </p>
                    <ul className="list-disc pl-5 space-y-2">
                      <li><strong>Social Security:</strong> Government benefits based on your work history and when you begin claiming</li>
                      <li><strong>Pension plans:</strong> Employer-sponsored defined benefit plans that provide guaranteed income</li>
                      <li><strong>Retirement account withdrawals:</strong> Systematic withdrawals from your 401(k), IRA, and other retirement accounts</li>
                      <li><strong>Dividend-producing investments:</strong> Stocks, funds, and REITs that provide regular income</li>
                      <li><strong>Annuities:</strong> Insurance products that can provide guaranteed income for life</li>
                      <li><strong>Part-time work:</strong> Continuing to work part-time in retirement to supplement income</li>
                    </ul>
                  </div>
                </DialogContent>
              </Dialog>
            </TabsContent>

            {/* Tools Tab */}
            <TabsContent value="tools" className="mt-0">
              {showCompoundCalculator && (
                <CompoundInterestCalculator onBack={() => setShowCompoundCalculator(false)} />
              )}
              
              {showBudgetPlanner && (
                <BudgetPlanner onBack={() => setShowBudgetPlanner(false)} />
              )}
              
              {!showCompoundCalculator && !showBudgetPlanner && (
                <>
                  <div className="mb-8 text-center">
                    <h2 className="text-2xl font-bold">Interactive Financial Calculators</h2>
                    <p className="text-neutral-400 mt-2">Powerful tools to help you make smarter financial decisions</p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <motion.div
                      whileHover={{ y: -5 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Card className="bg-zinc-900 border-zinc-800 h-full">
                        <CardHeader>
                          <div className="flex justify-between">
                            <div className="h-12 w-12 bg-primary/10 rounded-xl flex items-center justify-center mb-2">
                              <Calculator className="h-6 w-6 text-primary" />
                            </div>
                            <Badge>Interactive</Badge>
                          </div>
                          <CardTitle>Compound Interest Calculator</CardTitle>
                          <CardDescription>See how your investments can grow over time</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-neutral-400 mb-4">
                            Calculate how compound interest can significantly increase your savings and investments over various time periods.
                          </p>
                          <div className="bg-black/20 p-3 rounded-lg mb-4">
                            <p className="text-xs text-neutral-300">Example: $10,000 at 7% for 10 years = <span className="text-primary font-medium">$19,671.51</span></p>
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button 
                            className="w-full group" 
                            onClick={() => setShowCompoundCalculator(true)}
                          >
                            Use Calculator
                            <ChevronRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                          </Button>
                        </CardFooter>
                      </Card>
                    </motion.div>

                    <motion.div
                      whileHover={{ y: -5 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Card className="bg-zinc-900 border-zinc-800 h-full">
                        <CardHeader>
                          <div className="flex justify-between">
                            <div className="h-12 w-12 bg-amber-500/10 rounded-xl flex items-center justify-center mb-2">
                              <BarChart2 className="h-6 w-6 text-amber-400" />
                            </div>
                            <Badge>Interactive</Badge>
                          </div>
                          <CardTitle>Budget Planner</CardTitle>
                          <CardDescription>Create and manage your personal budget</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-neutral-400 mb-4">
                            Plan your monthly expenses, set savings goals, and track your progress with our interactive budget tool.
                          </p>
                          <div className="bg-black/20 p-3 rounded-lg mb-4">
                            <p className="text-xs text-neutral-300">Features: Income tracking, expense categories, savings goals, and export functionality</p>
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button 
                            className="w-full group" 
                            onClick={() => setShowBudgetPlanner(true)}
                          >
                            Use Budget Planner
                            <ChevronRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                          </Button>
                        </CardFooter>
                      </Card>
                    </motion.div>

                    <motion.div
                      whileHover={{ y: -5 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Card className="bg-zinc-900 border-zinc-800 h-full">
                        <CardHeader>
                          <div className="flex justify-between">
                            <div className="h-12 w-12 bg-green-500/10 rounded-xl flex items-center justify-center mb-2">
                              <DollarSign className="h-6 w-6 text-green-400" />
                            </div>
                            <Badge>Interactive</Badge>
                          </div>
                          <CardTitle>Retirement Calculator</CardTitle>
                          <CardDescription>Plan for your financial future</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-neutral-400 mb-4">
                            Estimate how much you need to save for retirement and track your progress toward your goals.
                          </p>
                          <div className="bg-black/20 p-3 rounded-lg mb-4">
                            <p className="text-xs text-neutral-300">Consider: current age, retirement age, life expectancy, current savings, and monthly contributions</p>
                          </div>
                        </CardContent>
                        <CardFooter>
                          <Button className="w-full group">
                            Use Calculator
                            <ChevronRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                          </Button>
                        </CardFooter>
                      </Card>
                    </motion.div>
                  </div>
                  
                  <div className="mt-10 mb-8 text-center">
                    <h2 className="text-2xl font-bold">Downloads & Templates</h2>
                    <p className="text-neutral-400 mt-2">Useful resources to help organize your finances</p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <motion.div
                      whileHover={{ y: -5 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Card className="bg-zinc-900 border-zinc-800 h-full">
                        <CardHeader>
                          <div className="flex justify-between">
                            <div className="h-12 w-12 bg-blue-500/10 rounded-xl flex items-center justify-center mb-2">
                              <Download className="h-6 w-6 text-blue-400" />
                            </div>
                            <Badge variant="outline">Template</Badge>
                          </div>
                          <CardTitle>Investment Tracker Spreadsheet</CardTitle>
                          <CardDescription>Track all your investments in one place</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-neutral-400 mb-4">
                            Download our professionally designed spreadsheet to track and analyze your investment portfolio performance.
                          </p>
                        </CardContent>
                        <CardFooter>
                          <Button
                            className="w-full group"
                            variant="outline"
                            onClick={() => openExternalLink('https://templates.office.com/en-us/investment-tracker-tm16400623')}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Download Template
                          </Button>
                        </CardFooter>
                      </Card>
                    </motion.div>
                    
                    <motion.div
                      whileHover={{ y: -5 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Card className="bg-zinc-900 border-zinc-800 h-full">
                        <CardHeader>
                          <div className="flex justify-between">
                            <div className="h-12 w-12 bg-purple-500/10 rounded-xl flex items-center justify-center mb-2">
                              <FileText className="h-6 w-6 text-purple-400" />
                            </div>
                            <Badge variant="outline">PDF Guide</Badge>
                          </div>
                          <CardTitle>Emergency Fund Workbook</CardTitle>
                          <CardDescription>Build your financial safety net</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-neutral-400 mb-4">
                            A comprehensive guide to establishing and maintaining your emergency fund with worksheets and trackers.
                          </p>
                        </CardContent>
                        <CardFooter>
                          <Button
                            className="w-full group"
                            variant="outline"
                            onClick={() => openExternalLink('https://www.consumerfinance.gov/start-small-save-up/start-saving/')}
                          >
                            <Download className="h-4 w-4 mr-2" />
                            Download PDF
                          </Button>
                        </CardFooter>
                      </Card>
                    </motion.div>
                    
                    <motion.div
                      whileHover={{ y: -5 }}
                      transition={{ duration: 0.3 }}
                    >
                      <Card className="bg-zinc-900 border-zinc-800 h-full">
                        <CardHeader>
                          <div className="flex justify-between">
                            <div className="h-12 w-12 bg-pink-500/10 rounded-xl flex items-center justify-center mb-2">
                              <ExternalLink className="h-6 w-6 text-pink-400" />
                            </div>
                            <Badge variant="outline">External Tool</Badge>
                          </div>
                          <CardTitle>Financial Goal Calculator</CardTitle>
                          <CardDescription>Plan and achieve your money goals</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-neutral-400 mb-4">
                            Use this third-party tool to set realistic financial goals and create a personalized action plan.
                          </p>
                        </CardContent>
                        <CardFooter>
                          <Button
                            className="w-full group"
                            variant="outline"
                            onClick={() => openExternalLink('https://www.investor.gov/financial-tools-calculators/calculators/compound-interest-calculator')}
                          >
                            <ExternalLink className="h-4 w-4 mr-2" />
                            Visit External Tool
                          </Button>
                        </CardFooter>
                      </Card>
                    </motion.div>
                  </div>
                </>
              )}
            </TabsContent>

            {/* Glossary Tab */}
            <TabsContent value="glossary" className="mt-0">
              <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6">
                <div className="mb-6">
                  <Input 
                    type="text" 
                    placeholder="Search financial terms..." 
                    className="bg-black border-zinc-800"
                  />
                </div>
                
                <div className="space-y-6">
                  <div>
                    <h3 className="text-xl font-bold mb-4 text-primary">A</h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-lg font-semibold mb-1">Annual Percentage Rate (APR)</h4>
                        <p className="text-neutral-400">The yearly interest rate charged for a loan or earned on an investment, expressed as a percentage.</p>
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold mb-1">Amortization</h4>
                        <p className="text-neutral-400">The process of gradually paying off a debt over time through regular payments of principal and interest.</p>
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold mb-1">Asset Allocation</h4>
                        <p className="text-neutral-400">The investment strategy of dividing investments among different asset categories, such as stocks, bonds, and cash.</p>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-bold mb-4 text-primary">B</h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-lg font-semibold mb-1">Bond</h4>
                        <p className="text-neutral-400">A fixed-income investment representing a loan made by an investor to a borrower (typically corporate or governmental).</p>
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold mb-1">Bull Market</h4>
                        <p className="text-neutral-400">A market condition in which prices are rising or expected to rise in the financial markets.</p>
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold mb-1">Budget</h4>
                        <p className="text-neutral-400">A financial plan that outlines expected income and expenses over a period of time.</p>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-xl font-bold mb-4 text-primary">C</h3>
                    <div className="space-y-4">
                      <div>
                        <h4 className="text-lg font-semibold mb-1">Capital Gain</h4>
                        <p className="text-neutral-400">The profit realized from selling an asset for more than its purchase price.</p>
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold mb-1">Compound Interest</h4>
                        <p className="text-neutral-400">Interest calculated on the initial principal and the accumulated interest over previous periods.</p>
                      </div>
                      <div>
                        <h4 className="text-lg font-semibold mb-1">Credit Score</h4>
                        <p className="text-neutral-400">A numerical expression based on a statistical analysis of a person's credit files, representing their creditworthiness.</p>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8 text-center">
                  <Button onClick={() => openExternalLink('https://www.investor.gov/introduction-investing/investing-basics/glossary')}>
                    View Full Glossary
                  </Button>
                </div>
              </div>
            </TabsContent>

            {/* FAQ Tab */}
            <TabsContent value="faq" className="mt-0">
              <div className="space-y-6">
                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader>
                    <CardTitle className="flex items-start gap-3">
                      <HelpCircle className="h-6 w-6 text-primary shrink-0 mt-1" />
                      <span>How should I start planning for retirement in my 20s?</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-neutral-400 mb-4">
                      Starting retirement planning in your 20s gives you the advantage of time. Begin by:
                    </p>
                    <ul className="list-disc pl-5 space-y-2 text-neutral-400">
                      <li>Contributing to employer-sponsored retirement plans like 401(k)s, especially if your employer offers matching contributions</li>
                      <li>Opening a Roth IRA for tax-free growth potential</li>
                      <li>Building an emergency fund to prevent early withdrawals from retirement accounts</li>
                      <li>Keeping debt, particularly high-interest debt, to a minimum</li>
                      <li>Adopting a consistent investment strategy that aligns with your long-term goals</li>
                    </ul>
                  </CardContent>
                </Card>

                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader>
                    <CardTitle className="flex items-start gap-3">
                      <HelpCircle className="h-6 w-6 text-primary shrink-0 mt-1" />
                      <span>What's the difference between a Roth IRA and a Traditional IRA?</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-neutral-400 mb-4">
                      The key differences between Roth IRAs and Traditional IRAs relate to when you pay taxes:
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="bg-zinc-800 p-4 rounded-lg">
                        <h4 className="font-bold mb-2">Traditional IRA</h4>
                        <ul className="list-disc pl-5 space-y-1 text-sm text-neutral-400">
                          <li>Contributions may be tax-deductible in the year they're made</li>
                          <li>Taxes are paid on withdrawals during retirement</li>
                          <li>Required minimum distributions (RMDs) start at age 72</li>
                          <li>Early withdrawals before age 59½ incur penalties plus taxes</li>
                        </ul>
                      </div>
                      <div className="bg-zinc-800 p-4 rounded-lg">
                        <h4 className="font-bold mb-2">Roth IRA</h4>
                        <ul className="list-disc pl-5 space-y-1 text-sm text-neutral-400">
                          <li>Contributions are made with after-tax dollars (no immediate tax benefit)</li>
                          <li>Qualified withdrawals in retirement are tax-free</li>
                          <li>No required minimum distributions during your lifetime</li>
                          <li>Original contributions can be withdrawn penalty-free anytime</li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader>
                    <CardTitle className="flex items-start gap-3">
                      <HelpCircle className="h-6 w-6 text-primary shrink-0 mt-1" />
                      <span>How much should I have in my emergency fund?</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-neutral-400 mb-4">
                      Financial experts typically recommend keeping 3-6 months of essential living expenses in an emergency fund. However, the ideal amount can vary based on:
                    </p>
                    <ul className="list-disc pl-5 space-y-2 text-neutral-400">
                      <li>Job stability and income predictability</li>
                      <li>Whether you're a single or dual-income household</li>
                      <li>Your monthly expenses and financial obligations</li>
                      <li>Health considerations and insurance coverage</li>
                    </ul>
                    <p className="text-neutral-400 mt-4">
                      Your emergency fund should be kept in a highly liquid account that you can access immediately when needed, such as a high-yield savings account.
                    </p>
                  </CardContent>
                </Card>
              </div>
              
              <div className="mt-8 text-center">
                <Button onClick={() => openExternalLink('https://www.investor.gov/introduction-investing/investing-basics/investment-products/mutual-funds-and-exchange-traded-funds/mutual')}>
                  View All FAQs
                </Button>
              </div>
            </TabsContent>

            {/* News Tab */}
            <TabsContent value="news" className="mt-0">
              <div className="space-y-6">
                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                        Market Update
                      </Badge>
                      <span className="text-sm text-neutral-500">April 4, 2025</span>
                    </div>
                    <CardTitle>Federal Reserve Announces Interest Rate Decision</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-neutral-400 mb-4">
                      The Federal Reserve announced its latest decision on interest rates today, impacting borrowing costs for consumers and businesses. Here's what it means for your finances.
                    </p>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button 
                      variant="outline" 
                      className="flex items-center gap-2"
                      onClick={() => openExternalLink('https://www.federalreserve.gov/newsevents/pressreleases.htm')}
                    >
                      Read Full Article
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>

                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline" className="bg-amber-500/10 text-amber-400 border-amber-500/20">
                        Investment Strategy
                      </Badge>
                      <span className="text-sm text-neutral-500">April 2, 2025</span>
                    </div>
                    <CardTitle>Diversification Strategies for Volatile Markets</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-neutral-400 mb-4">
                      With market volatility increasing, experts recommend revisiting portfolio diversification strategies. Learn about asset allocation approaches that can help protect your investments.
                    </p>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button 
                      variant="outline" 
                      className="flex items-center gap-2"
                      onClick={() => openExternalLink('https://www.investor.gov/introduction-investing/investing-basics/investment-products/stocks')}
                    >
                      Read Full Article
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>

                <Card className="bg-zinc-900 border-zinc-800">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline" className="bg-green-500/10 text-green-400 border-green-500/20">
                        Personal Finance
                      </Badge>
                      <span className="text-sm text-neutral-500">March 29, 2025</span>
                    </div>
                    <CardTitle>New Tax Law Changes: What You Need to Know</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-neutral-400 mb-4">
                      Recent tax legislation has introduced several changes that could affect your filing status and deductions. Here's a breakdown of the key updates and how they might impact your finances.
                    </p>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button 
                      variant="outline" 
                      className="flex items-center gap-2"
                      onClick={() => openExternalLink('https://www.irs.gov/newsroom/tax-reform')}
                    >
                      Read Full Article
                      <ExternalLink className="h-4 w-4" />
                    </Button>
                  </CardFooter>
                </Card>
              </div>
              
              <div className="mt-8 text-center">
                <Button onClick={() => openExternalLink('https://www.wsj.com/section/markets')}>
                  View All News
                </Button>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}