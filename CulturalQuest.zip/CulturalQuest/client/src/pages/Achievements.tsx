import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AchievementBadge } from "@/components/AchievementBadge";
import { Progress } from "@/components/ui/progress";
import { useAuth } from "@/contexts/AuthContext";
import { Award, Flag, Target } from "lucide-react";

export default function Achievements() {
  const { user } = useAuth();
  
  // Fetch all available achievements
  const { data: allAchievements, isLoading: achievementsLoading } = useQuery({
    queryKey: ["/api/achievements"],
  });
  
  // Fetch user's earned achievements
  const { data: userAchievements, isLoading: userAchievementsLoading } = useQuery({
    queryKey: ["/api/achievements/user"],
  });
  
  const isLoading = achievementsLoading || userAchievementsLoading;
  
  // Helper function to check if user has earned an achievement
  const hasEarnedAchievement = (achievementId: number) => {
    if (!userAchievements) return false;
    return userAchievements.some(ua => ua.achievementId === achievementId);
  };
  
  // Calculate achievement completion percentage
  const achievementPercentage = userAchievements && allAchievements
    ? Math.round((userAchievements.length / allAchievements.length) * 100)
    : 0;
  
  return (
    <div className="container max-w-6xl mx-auto py-8 px-4">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Your Achievements</h1>
        <p className="text-neutral-600 mt-1">
          Track your progress and earn badges as you learn
        </p>
      </div>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
        {/* Achievement Completion */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="bg-primary bg-opacity-20 p-3 rounded-full mr-4">
                <Award className="text-primary h-6 w-6" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Achievement Progress</h3>
                <Progress className="mt-2 h-2" value={achievementPercentage} />
                <p className="text-sm text-neutral-600 mt-1">
                  {userAchievements?.length || 0} of {allAchievements?.length || 0} earned
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Current Level */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="bg-blue-100 p-3 rounded-full mr-4">
                <Target className="text-blue-600 h-6 w-6" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Current Level</h3>
                <p className="text-3xl font-bold text-blue-600 mt-1">
                  {user?.level || 1}
                </p>
                <p className="text-sm text-neutral-600">Level {user?.level || 1} Investor</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Total XP */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center">
              <div className="bg-amber-100 p-3 rounded-full mr-4">
                <Flag className="text-amber-600 h-6 w-6" />
              </div>
              <div>
                <h3 className="font-medium text-lg">Total XP</h3>
                <p className="text-3xl font-bold text-amber-600 mt-1">
                  {user?.experience || 0}
                </p>
                <p className="text-sm text-neutral-600">
                  {user?.experience ? Math.round(user.experience / 10) : 0} lessons completed
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Achievement Categories */}
      <div className="mb-10">
        <h2 className="text-2xl font-bold mb-6">Financial Milestones</h2>
        
        {isLoading ? (
          <div className="text-center py-10">Loading achievements...</div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-6">
            {/* Map through all achievements */}
            {allAchievements?.map(achievement => {
              const isEarned = hasEarnedAchievement(achievement.id);
              const userAchievement = userAchievements?.find(
                ua => ua.achievementId === achievement.id
              );
              
              return (
                <AchievementBadge
                  key={achievement.id}
                  name={achievement.name}
                  iconName={achievement.iconName}
                  locked={!isEarned}
                  earnedDate={userAchievement?.earnedAt ? new Date(userAchievement.earnedAt) : undefined}
                  requirement={!isEarned ? achievement.description : undefined}
                />
              );
            })}
          </div>
        )}
      </div>
      
      {/* Upcoming Achievements */}
      <div>
        <h2 className="text-2xl font-bold mb-6">Upcoming Achievements</h2>
        
        <Card>
          <CardHeader>
            <CardTitle>Continue Learning to Earn More Badges</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center">
                <div className="bg-neutral-100 p-3 rounded-full mr-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neutral-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="8" r="6" />
                    <path d="M12 14v7" />
                    <path d="M8 19h8" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-medium">Complete your first investing course</h3>
                  <p className="text-sm text-neutral-600">Earn the "Smart Investor" badge</p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="bg-neutral-100 p-3 rounded-full mr-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neutral-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 2L2 7l10 5 10-5-10-5Z" />
                    <path d="M2 17l10 5 10-5" />
                    <path d="M2 12l10 5 10-5" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-medium">Reach level 5</h3>
                  <p className="text-sm text-neutral-600">Earn the "Finance Explorer" badge</p>
                </div>
              </div>
              
              <div className="flex items-center">
                <div className="bg-neutral-100 p-3 rounded-full mr-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-neutral-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <circle cx="12" cy="12" r="10" />
                    <polyline points="12 6 12 12 16 14" />
                  </svg>
                </div>
                <div>
                  <h3 className="font-medium">Maintain a 30-day streak</h3>
                  <p className="text-sm text-neutral-600">Earn the "Dedication Master" badge</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
