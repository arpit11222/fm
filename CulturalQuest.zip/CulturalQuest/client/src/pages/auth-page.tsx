import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

// Login form schema
const loginSchema = z.object({
  username: z.string().min(3, {
    message: "Username must be at least 3 characters long",
  }),
  password: z.string().min(6, {
    message: "Password must be at least 6 characters long",
  }),
});

// Registration form schema
const registerSchema = z.object({
  username: z.string().min(3, {
    message: "Username must be at least 3 characters long",
  }),
  displayName: z.string().min(2, {
    message: "Display name must be at least 2 characters long",
  }),
  email: z.string().email({
    message: "Please enter a valid email address",
  }),
  password: z.string().min(6, {
    message: "Password must be at least 6 characters long",
  }),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

export default function AuthPage() {
  const [location, setLocation] = useLocation();
  const { user, login } = useAuth();
  const [loginLoading, setLoginLoading] = useState(false);
  const [registerLoading, setRegisterLoading] = useState(false);
  const { toast } = useToast();
  
  // Get tab from URL parameter if available
  const params = new URLSearchParams(typeof window !== 'undefined' ? window.location.search : '');
  const tabParam = params.get('tab');
  const [activeTab, setActiveTab] = useState(tabParam === 'register' ? 'register' : 'login');
  
  // Redirect if already logged in
  if (user) {
    console.log("User already logged in, redirecting to home page using direct navigation");
    window.location.href = "/";
    return null;
  }
  
  // Login form
  const loginForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });
  
  // Registration form
  const registerForm = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      displayName: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });
  
  // Login submission
  async function onLoginSubmit(values: z.infer<typeof loginSchema>) {
    setLoginLoading(true);
    try {
      console.log("Login Form - Submitting login for:", values.username);
      
      // Special handling for demo user
      if (values.username === "demo" && values.password === "password123") {
        console.log("Using demo credentials with direct endpoint...");
        
        // Use the special demo login endpoint
        const response = await fetch("/api/auth/demo-login", {
          method: "POST",
          credentials: "include"
        });
        
        if (!response.ok) {
          throw new Error("Failed to login with demo account");
        }
        
        const userData = await response.json();
        console.log("Demo login successful:", userData);
        
        // Force a refresh of the auth context
        login(values.username, values.password).catch(err => {
          console.log("Auth context update not needed, proceeding with redirect");
        });
        
        // Show success message
        toast({
          title: "Welcome, Demo User!",
          description: "You've successfully signed in with the demo account.",
        });
        
        // Add a small delay before redirect to ensure context is updated
        console.log("Demo login successful, redirecting...");
        setTimeout(() => {
          window.location.href = "/"; // Use direct navigation instead of wouter
        }, 500);
        
        return;
      }
      
      // Normal login flow for non-demo users
      await login(values.username, values.password);
      
      // Show success message
      toast({
        title: "Welcome back!",
        description: "You've successfully signed in.",
      });
      
      // Add a small delay before redirect to ensure context is updated
      console.log("Login Form - Login successful, redirecting...");
      setTimeout(() => {
        window.location.href = "/"; // Use direct navigation instead of wouter
      }, 300);
    } catch (error: any) {
      console.error("Login Form - Login error:", error);
      toast({
        title: "Sign in failed",
        description: error.message || "Invalid username or password.",
        variant: "destructive",
      });
    } finally {
      setLoginLoading(false);
    }
  }
  
  // Registration submission
  async function onRegisterSubmit(values: z.infer<typeof registerSchema>) {
    setRegisterLoading(true);
    try {
      const { confirmPassword, ...userData } = values;
      
      // 1. Register the user
      const registerResponse = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData),
        credentials: 'include'
      });
      
      if (!registerResponse.ok) {
        const errorData = await registerResponse.json();
        throw new Error(errorData.message || "Registration failed");
      }
      
      // 2. Automatically log the user in after registration using the login function from AuthContext
      try {
        await login(values.username, values.password);
        
        // Login successful - redirect to home page
        toast({
          title: "Welcome to FinMate!",
          description: "Your account has been created and you're now logged in.",
        });
        
        // Small delay before redirect to ensure state is updated
        setTimeout(() => {
          window.location.href = "/"; // Use direct navigation instead of wouter
        }, 300);
      } catch (loginError) {
        console.error("Auto-login after registration failed:", loginError);
        
        // If login fails after registration
        toast({
          title: "Account created successfully!",
          description: "Please sign in with your credentials.",
        });
        
        // Switch to login tab
        setActiveTab("login");
        
        // Update URL
        const url = new URL(window.location.href);
        url.searchParams.delete('tab');
        window.history.replaceState({}, '', url.toString());
        
        // Pre-fill the login form
        loginForm.setValue("username", values.username);
        loginForm.setValue("password", "");
      }
    } catch (error: any) {
      console.error("Registration error:", error);
      toast({
        title: "Registration failed",
        description: error.message || "There was an error creating your account.",
        variant: "destructive",
      });
    } finally {
      setRegisterLoading(false);
    }
  }
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary/10 py-12 md:py-0">
      <div className="container flex min-h-[calc(100vh-8rem)] items-center justify-center">
        <div className="grid w-full gap-6 md:grid-cols-2 lg:gap-12">
          {/* Left column: Auth forms */}
          <div className="flex items-center justify-center">
            <Tabs 
              defaultValue="login" 
              value={activeTab} 
              onValueChange={(value) => {
                setActiveTab(value);
                const url = new URL(window.location.href);
                if (value === 'register') {
                  url.searchParams.set('tab', 'register');
                } else {
                  url.searchParams.delete('tab');
                }
                window.history.replaceState({}, '', url.toString());
              }}
              className="w-full max-w-md space-y-4"
            >
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>
              
              {/* Login form */}
              <TabsContent value="login">
                <Card>
                  <CardHeader className="space-y-1">
                    <CardTitle className="text-2xl font-bold">Sign In</CardTitle>
                    <CardDescription>
                      Enter your username and password to access your account
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...loginForm}>
                      <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                        <FormField
                          control={loginForm.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Username</FormLabel>
                              <FormControl>
                                <Input placeholder="Enter your username" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={loginForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="Enter your password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button type="submit" className="w-full" disabled={loginLoading}>
                          {loginLoading ? "Signing in..." : "Sign In"}
                        </Button>
                        
                        <div className="relative mt-2">
                          <div className="absolute inset-0 flex items-center">
                            <span className="w-full border-t" />
                          </div>
                          <div className="relative flex justify-center text-xs uppercase">
                            <span className="bg-card px-2 text-muted-foreground">Or</span>
                          </div>
                        </div>
                        
                        <Button 
                          type="button"
                          variant="outline" 
                          className="w-full mt-2"
                          onClick={() => {
                            // Pre-fill demo credentials
                            loginForm.setValue("username", "demo");
                            loginForm.setValue("password", "password123");
                            
                            // Submit the form
                            const formValues = { username: "demo", password: "password123" };
                            onLoginSubmit(formValues);
                          }}
                        >
                          Try Demo Account
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Registration form */}
              <TabsContent value="register">
                <Card>
                  <CardHeader className="space-y-1">
                    <CardTitle className="text-2xl font-bold">Create an Account</CardTitle>
                    <CardDescription>
                      Enter your information to create a new account
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...registerForm}>
                      <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                        <FormField
                          control={registerForm.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Username</FormLabel>
                              <FormControl>
                                <Input placeholder="Choose a username" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={registerForm.control}
                          name="displayName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Display Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Your full name" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={registerForm.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="Your email address" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={registerForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="Create a password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={registerForm.control}
                          name="confirmPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Confirm Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="Confirm your password" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <Button type="submit" className="w-full" disabled={registerLoading}>
                          {registerLoading ? "Creating account..." : "Sign Up"}
                        </Button>
                      </form>
                    </Form>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
          
          {/* Right column: Hero section */}
          <div className="hidden md:block">
            <div className="rounded-lg border bg-card p-8 text-card-foreground shadow">
              <div className="space-y-4">
                <h2 className="text-3xl font-bold tracking-tight">Financial Education Simplified</h2>
                <p className="text-muted-foreground">
                  Welcome to FinMate, your personalized journey to financial literacy. 
                  Master essential financial concepts with our interactive learning experience.
                </p>
                <ul className="space-y-2">
                  <li className="flex items-center">
                    <span className="mr-2 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground">✓</span>
                    <span>Interactive courses with real-world applications</span>
                  </li>
                  <li className="flex items-center">
                    <span className="mr-2 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground">✓</span>
                    <span>Track your progress and earn achievements</span>
                  </li>
                  <li className="flex items-center">
                    <span className="mr-2 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground">✓</span>
                    <span>Practice with financial calculators and tools</span>
                  </li>
                  <li className="flex items-center">
                    <span className="mr-2 flex h-6 w-6 items-center justify-center rounded-full bg-primary text-primary-foreground">✓</span>
                    <span>Access resources and stay updated with financial news</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}