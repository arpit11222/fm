import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { BarChart3, PieChart, LineChart, Trophy, Calendar, Clock, BarChart, Activity } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import {
  LineChart as RechartsLineChart,
  Line,
  CartesianGrid,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart as RechartsBarChart,
  Bar,
  PieChart as RechartsPieChart,
  Pie,
  Cell
} from "recharts";

// Sample data for charts
const weeklyActivityData = [
  { day: "Mon", minutes: 25, lessons: 2 },
  { day: "Tue", minutes: 35, lessons: 3 },
  { day: "Wed", minutes: 45, lessons: 4 },
  { day: "Thu", minutes: 20, lessons: 1 },
  { day: "Fri", minutes: 60, lessons: 5 },
  { day: "Sat", minutes: 40, lessons: 3 },
  { day: "Sun", minutes: 30, lessons: 2 }
];

const monthlyProgressData = [
  { month: "Jan", completed: 5 },
  { month: "Feb", completed: 8 },
  { month: "Mar", completed: 12 },
  { month: "Apr", completed: 9 },
  { month: "May", completed: 15 },
  { month: "Jun", completed: 18 }
];

const categoryData = [
  { name: "Personal Finance", value: 40, color: "#4F46E5" },
  { name: "Investing", value: 30, color: "#EC4899" }, 
  { name: "Insurance", value: 15, color: "#10B981" },
  { name: "Tax Planning", value: 15, color: "#F59E0B" }
];

const COLORS = ["#4F46E5", "#EC4899", "#10B981", "#F59E0B"];

export default function AnalyticsPage() {
  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
  });

  const { data: progress } = useQuery({
    queryKey: ["/api/user/progress"],
  });

  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <div className="bg-black py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                Your Learning <span className="text-primary">Analytics</span>
              </h1>
              <p className="text-lg text-neutral-400 mb-8">
                Track your progress, analyze your study patterns, and visualize your financial learning journey.
              </p>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Stats Overview Cards */}
      <div className="py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader className="pb-2">
                <CardDescription>Current Streak</CardDescription>
                <CardTitle className="text-3xl flex items-center gap-2">
                  {user?.streak || 0} days
                  <Trophy className="h-5 w-5 text-amber-500" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-neutral-400">
                  Keep going! Study daily to increase your streak.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader className="pb-2">
                <CardDescription>Total XP</CardDescription>
                <CardTitle className="text-3xl flex items-center gap-2">
                  {user?.experience || 0} XP
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center text-sm mb-1">
                  <span className="text-neutral-400">Level {user?.level || 1}</span>
                  <span className="text-primary">{(user?.experience || 0) % 1000} / 1000</span>
                </div>
                <Progress value={((user?.experience || 0) % 1000) / 10} className="h-1" />
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader className="pb-2">
                <CardDescription>Courses Completed</CardDescription>
                <CardTitle className="text-3xl">
                  {progress?.filter(p => p.progress === 100).length || 0}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-neutral-400">
                  Out of {progress?.length || 0} courses started
                </p>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800">
              <CardHeader className="pb-2">
                <CardDescription>Study Time</CardDescription>
                <CardTitle className="text-3xl flex items-center gap-2">
                  42h <Clock className="h-5 w-5 text-primary" />
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-neutral-400">
                  This month: 14h (+12% from last month)
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Activity Chart */}
      <div className="py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <BarChart3 className="h-6 w-6 text-primary" />
              Weekly Activity
            </h2>
            <p className="text-neutral-400">Your learning pattern over the past 7 days</p>
          </div>

          <Card className="bg-zinc-900 border-zinc-800 p-6">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsBarChart data={weeklyActivityData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="day" stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a' }} 
                    labelStyle={{ color: '#f1f5f9' }}
                  />
                  <Legend />
                  <Bar dataKey="minutes" name="Minutes Studied" fill="#4f46e5" />
                  <Bar dataKey="lessons" name="Lessons Completed" fill="#ec4899" />
                </RechartsBarChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>
      </div>

      {/* Progress Timeline and Category Distribution */}
      <div className="py-10 grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <LineChart className="h-6 w-6 text-primary" />
              Monthly Progress
            </h2>
            <p className="text-neutral-400">Lessons completed over the past 6 months</p>
          </div>

          <Card className="bg-zinc-900 border-zinc-800 p-6">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsLineChart data={monthlyProgressData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis dataKey="month" stroke="#94a3b8" />
                  <YAxis stroke="#94a3b8" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a' }} 
                    labelStyle={{ color: '#f1f5f9' }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="completed" 
                    name="Completed Lessons" 
                    stroke="#4f46e5" 
                    strokeWidth={2}
                    activeDot={{ r: 8 }} 
                  />
                </RechartsLineChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <PieChart className="h-6 w-6 text-primary" />
              Learning Distribution
            </h2>
            <p className="text-neutral-400">Your focus across financial categories</p>
          </div>

          <Card className="bg-zinc-900 border-zinc-800 p-6">
            <div className="h-80 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <RechartsPieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={120}
                    fill="#8884d8"
                    dataKey="value"
                    nameKey="name"
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a' }} 
                    labelStyle={{ color: '#f1f5f9' }}
                  />
                </RechartsPieChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>
      </div>

      {/* Learning Calendar */}
      <div className="py-10 bg-zinc-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Calendar className="h-6 w-6 text-primary" />
              Activity Calendar
            </h2>
            <p className="text-neutral-400">Your daily learning activity for the past month</p>
          </div>

          <Card className="bg-zinc-900 border-zinc-800 p-6">
            <div className="grid grid-cols-7 gap-2">
              {Array.from({ length: 30 }).map((_, i) => {
                // Generate random intensity for demo purposes
                const intensity = Math.floor(Math.random() * 5);
                let bgColor = "bg-zinc-800";
                if (intensity === 1) bgColor = "bg-primary/20";
                if (intensity === 2) bgColor = "bg-primary/40";
                if (intensity === 3) bgColor = "bg-primary/60";
                if (intensity === 4) bgColor = "bg-primary/80";
                
                return (
                  <div 
                    key={i} 
                    className={`h-10 w-10 rounded-md ${bgColor} flex items-center justify-center hover:ring-2 hover:ring-primary transition-all cursor-pointer`}
                    title={`${Math.floor(Math.random() * 60)} minutes of study`}
                  >
                    {i + 1}
                  </div>
                );
              })}
            </div>
            <div className="flex items-center justify-end mt-4 gap-2 text-sm text-neutral-400">
              <div className="flex items-center gap-1">
                <div className="h-3 w-3 bg-zinc-800 rounded-sm"></div>
                <span>None</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="h-3 w-3 bg-primary/20 rounded-sm"></div>
                <span>Light</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="h-3 w-3 bg-primary/60 rounded-sm"></div>
                <span>Medium</span>
              </div>
              <div className="flex items-center gap-1">
                <div className="h-3 w-3 bg-primary/80 rounded-sm"></div>
                <span>High</span>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Learning Goals */}
      <div className="py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-end mb-6">
            <div>
              <h2 className="text-2xl font-bold flex items-center gap-2">
                <Activity className="h-6 w-6 text-primary" />
                Learning Goals
              </h2>
              <p className="text-neutral-400">Track your progress toward custom learning objectives</p>
            </div>
            <Button variant="outline">Set New Goal</Button>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <Card className="bg-zinc-900 border-zinc-800 p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Complete Investing Basics Course</h3>
                <Badge className="bg-primary/20 text-primary border-none">In Progress</Badge>
              </div>
              <div className="flex justify-between items-center text-sm mb-2">
                <span className="text-neutral-400">Progress</span>
                <span className="text-primary">65%</span>
              </div>
              <Progress value={65} className="h-2 mb-4" />
              <p className="text-neutral-400 text-sm mb-2">Due: April 20, 2025</p>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800 p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Complete 50 Daily Challenges</h3>
                <Badge className="bg-primary/20 text-primary border-none">In Progress</Badge>
              </div>
              <div className="flex justify-between items-center text-sm mb-2">
                <span className="text-neutral-400">Progress</span>
                <span className="text-primary">42%</span>
              </div>
              <Progress value={42} className="h-2 mb-4" />
              <p className="text-neutral-400 text-sm mb-2">21 / 50 challenges completed</p>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800 p-6">
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-lg font-semibold">Achieve 30-Day Learning Streak</h3>
                <Badge className="bg-primary/20 text-primary border-none">In Progress</Badge>
              </div>
              <div className="flex justify-between items-center text-sm mb-2">
                <span className="text-neutral-400">Progress</span>
                <span className="text-primary">{Math.min((user?.streak || 0) / 30 * 100, 100).toFixed(0)}%</span>
              </div>
              <Progress value={Math.min((user?.streak || 0) / 30 * 100, 100)} className="h-2 mb-4" />
              <p className="text-neutral-400 text-sm mb-2">{user?.streak || 0} / 30 days</p>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}