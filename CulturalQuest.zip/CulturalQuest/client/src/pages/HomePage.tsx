import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import Dashboard from "@/components/Dashboard";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { ChevronRight, DollarSign, TrendingUp, Award, Shield, Zap, Book } from "lucide-react";

export default function HomePage() {
  const { isAuthenticated, isLoading } = useAuth();
  
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-900">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }
  
  if (isAuthenticated) {
    return <Dashboard />;
  }
  
  // Landing page for non-authenticated users
  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <div className="bg-gradient-to-br from-black via-black to-black py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-16">
            <motion.div 
              className="md:max-w-xl"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="mb-6 flex items-center">
                <div className="bg-primary/20 border border-primary/30 px-4 py-1 rounded-full">
                  <span className="text-primary text-sm font-medium">Financial Freedom Awaits</span>
                </div>
              </div>
              <h1 className="text-4xl md:text-5xl font-bold mb-4 leading-tight">
                Master Finance Skills Through <span className="text-primary">Gamified Learning</span>
              </h1>
              <p className="text-xl mb-8 text-neutral-300">
                Interactive lessons, skill progression, and achievement tracking will guide you through your financial education journey.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href={isAuthenticated ? "/courses" : "/auth?tab=register"}>
                  <Button size="lg" className="group h-12 px-6 text-base">
                    Start Your Journey
                    <ChevronRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
                <Link href="/auth">
                  <Button size="lg" variant="outline" className="h-12 px-6 text-base">
                    Sign In
                  </Button>
                </Link>
              </div>
            </motion.div>
            
            <motion.div 
              className="md:w-1/2"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="relative bg-black rounded-2xl p-1 shadow-2xl overflow-hidden border border-zinc-800">
                <div className="absolute inset-0 bg-gradient-to-br from-primary/20 via-transparent to-primary/5 opacity-40"></div>
                <div className="relative rounded-xl overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1579621970795-87facc2f976d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                    alt="Finance Learning Path" 
                    className="w-full object-cover rounded-xl"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent"></div>
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <div className="flex justify-between mb-4">
                      <div className="flex space-x-2">
                        <div className="h-8 w-8 rounded-full bg-green-500 flex items-center justify-center">
                          <DollarSign className="h-4 w-4 text-white" />
                        </div>
                        <div className="h-8 w-8 rounded-full bg-yellow-500 flex items-center justify-center">
                          <TrendingUp className="h-4 w-4 text-white" />
                        </div>
                        <div className="h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center">
                          <Shield className="h-4 w-4 text-white" />
                        </div>
                      </div>
                      <div className="flex items-center px-2 py-1 bg-black/90 rounded-full">
                        <div className="h-2 w-2 rounded-full bg-green-500 mr-2"></div>
                        <span className="text-xs text-neutral-300">Live courses</span>
                      </div>
                    </div>
                    <h3 className="text-xl font-bold mb-2">Financial Skills Roadmap</h3>
                    <div className="w-full bg-zinc-800 h-2 rounded-full overflow-hidden">
                      <div className="bg-primary h-full rounded-full" style={{ width: '35%' }}></div>
                    </div>
                    <div className="flex justify-between mt-2 text-sm">
                      <span>Beginner</span>
                      <span>Intermediate</span>
                      <span>Advanced</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
      
      {/* Stats/Features Banner */}
      <div className="border-y border-zinc-800 bg-black py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="flex flex-col items-center text-center">
              <div className="text-3xl font-bold text-primary mb-1">20+</div>
              <div className="text-neutral-400 text-sm">Interactive Courses</div>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="text-3xl font-bold text-primary mb-1">100+</div>
              <div className="text-neutral-400 text-sm">Bite-sized Lessons</div>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="text-3xl font-bold text-primary mb-1">50+</div>
              <div className="text-neutral-400 text-sm">Achievements to Earn</div>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="text-3xl font-bold text-primary mb-1">24/7</div>
              <div className="text-neutral-400 text-sm">Learning Access</div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Features Section */}
      <div className="py-20 bg-black">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-block px-3 py-1 bg-primary/10 rounded-full text-primary text-sm font-medium mb-4">
              Key Features
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white">Financial Education Reimagined</h2>
            <p className="mt-4 text-xl text-neutral-400 max-w-3xl mx-auto">
              Our platform combines educational content with gamification to make learning finance engaging and effective.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              className="bg-zinc-900 p-8 rounded-2xl border border-zinc-800"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <div className="h-12 w-12 bg-blue-500/10 rounded-xl flex items-center justify-center mb-6 text-blue-400">
                <Book className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-white">Structured Learning Paths</h3>
              <p className="text-neutral-400">
                Follow carefully designed learning paths that build your financial knowledge from fundamentals to advanced concepts.
              </p>
            </motion.div>
            
            <motion.div 
              className="bg-zinc-900 p-8 rounded-2xl border border-zinc-800"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="h-12 w-12 bg-amber-500/10 rounded-xl flex items-center justify-center mb-6 text-amber-400">
                <TrendingUp className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-white">Progress Tracking</h3>
              <p className="text-neutral-400">
                Visualize your advancement with interactive skill trees and detailed progress metrics to keep you motivated.
              </p>
            </motion.div>
            
            <motion.div 
              className="bg-zinc-900 p-8 rounded-2xl border border-zinc-800"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <div className="h-12 w-12 bg-green-500/10 rounded-xl flex items-center justify-center mb-6 text-green-400">
                <Award className="h-6 w-6" />
              </div>
              <h3 className="text-xl font-bold mb-3 text-white">Achievement System</h3>
              <p className="text-neutral-400">
                Earn badges, maintain streaks, and collect experience points as you master financial concepts and complete challenges.
              </p>
            </motion.div>
          </div>
        </div>
      </div>
      
      {/* Topic Section */}
      <div className="py-20 bg-black/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-block px-3 py-1 bg-primary/10 rounded-full text-primary text-sm font-medium mb-4">
              Comprehensive Topics
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white">Master Every Aspect of Finance</h2>
            <p className="mt-4 text-xl text-neutral-400 max-w-3xl mx-auto">
              From basic budgeting to advanced investing strategies, our curriculum covers all the financial topics you need.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 hover:border-primary/50 transition-colors">
              <div className="h-10 w-10 bg-blue-500/20 rounded-lg flex items-center justify-center mb-4 text-blue-400">
                <DollarSign className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-white">Personal Finance</h3>
              <p className="text-neutral-400 text-sm">Budgeting, saving, and managing your daily finances</p>
            </div>
            
            <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 hover:border-primary/50 transition-colors">
              <div className="h-10 w-10 bg-amber-500/20 rounded-lg flex items-center justify-center mb-4 text-amber-400">
                <TrendingUp className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-white">Investing</h3>
              <p className="text-neutral-400 text-sm">Stocks, bonds, funds, and growing your wealth</p>
            </div>
            
            <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 hover:border-primary/50 transition-colors">
              <div className="h-10 w-10 bg-green-500/20 rounded-lg flex items-center justify-center mb-4 text-green-400">
                <Shield className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-white">Insurance</h3>
              <p className="text-neutral-400 text-sm">Protecting yourself and your assets properly</p>
            </div>
            
            <div className="bg-zinc-900 p-6 rounded-2xl border border-zinc-800 hover:border-primary/50 transition-colors">
              <div className="h-10 w-10 bg-purple-500/20 rounded-lg flex items-center justify-center mb-4 text-purple-400">
                <Zap className="h-5 w-5" />
              </div>
              <h3 className="text-lg font-semibold mb-2 text-white">Tax Strategies</h3>
              <p className="text-neutral-400 text-sm">Understanding and optimizing your tax situation</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* CTA Section */}
      <div className="py-20 bg-black border-t border-zinc-800">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="bg-gradient-to-br from-zinc-900 to-black p-10 rounded-3xl border border-zinc-800 shadow-xl"
          >
            <div className="inline-flex items-center justify-center p-2 bg-primary/10 rounded-full mb-6">
              <DollarSign className="h-6 w-6 text-primary" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Ready to Transform Your Finances?</h2>
            <p className="text-xl text-neutral-400 mb-8 max-w-2xl mx-auto">
              Join thousands of learners who are building financial knowledge and taking control of their future.
            </p>
            <Link href={isAuthenticated ? "/courses" : "/auth?tab=register"}>
              <Button size="lg" className="h-14 px-8 text-lg">
                Start Free Learning
              </Button>
            </Link>
            <p className="mt-4 text-sm text-neutral-500">No credit card required</p>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
