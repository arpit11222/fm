import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, ArrowRight, Lightbulb } from "lucide-react";
import { Separator } from "@/components/ui/separator";

export default function LessonPage() {
  const [, params] = useRoute("/lesson/:id");
  const lessonId = parseInt(params?.id || "0");
  const [showHint, setShowHint] = useState(false);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const { toast } = useToast();
  
  // Fetch lesson details
  const { data: lesson, isLoading: lessonLoading } = useQuery({
    queryKey: [`/api/lessons/${lessonId}`],
  });
  
  // Fetch user progress for this lesson
  const { data: progress, isLoading: progressLoading } = useQuery({
    queryKey: [`/api/progress/lesson/${lessonId}`],
  });
  
  const isLoading = lessonLoading || progressLoading;
  
  // Mutation to update lesson progress
  const { mutate, isPending } = useMutation({
    mutationFn: async (data: { completed: boolean, progress: number }) => {
      return apiRequest('POST', '/api/progress', {
        lessonId,
        courseId: lesson?.courseId,
        ...data
      });
    },
    onSuccess: () => {
      toast({
        title: "Progress saved!",
        description: `You've earned ${lesson?.xpReward} XP!`,
      });
      queryClient.invalidateQueries({ queryKey: [`/api/progress/lesson/${lessonId}`] });
      queryClient.invalidateQueries({ queryKey: [`/api/progress/course/${lesson?.courseId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
    },
    onError: (error) => {
      toast({
        title: "Error saving progress",
        description: String(error),
        variant: "destructive",
      });
    }
  });
  
  if (isLoading) {
    return (
      <div className="container max-w-3xl mx-auto py-8 px-4">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-full mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-5/6 mb-6"></div>
          <div className="h-64 bg-gray-200 rounded mb-4"></div>
          <div className="h-12 bg-gray-200 rounded mb-4"></div>
        </div>
      </div>
    );
  }
  
  if (!lesson) {
    return (
      <div className="container max-w-3xl mx-auto py-8 px-4">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Lesson not found</h1>
          <p className="mb-4">The lesson you're looking for doesn't exist.</p>
          <Link href="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }
  
  const content = lesson.content;
  const question = content.questions[0];
  
  const handleComplete = () => {
    if (question.type === "multiple-choice" && selectedOption !== null) {
      const isCorrect = selectedOption === question.correctAnswerIndex;
      mutate({ 
        completed: isCorrect, 
        progress: isCorrect ? 100 : 50 
      });
    } else {
      toast({
        title: "Please answer the question",
        description: "Select an answer before continuing.",
        variant: "destructive",
      });
    }
  };
  
  return (
    <div className="container max-w-3xl mx-auto py-8 px-4">
      {/* Lesson Header */}
      <div className="mb-8">
        <Link href={`/course/${lesson.courseId}`}>
          <Button variant="ghost" className="mb-2 -ml-2">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Course
          </Button>
        </Link>
        
        <h1 className="text-2xl font-bold">{lesson.title}</h1>
        <p className="text-neutral-600 mt-1">{lesson.description}</p>
        
        <div className="mt-4">
          <Progress value={progress?.progress || 0} className="h-2.5" />
          <div className="flex justify-between text-sm text-neutral-500 mt-2">
            <span>Lesson {lesson.order} of 5</span>
            <span>{lesson.xpReward} XP</span>
          </div>
        </div>
      </div>
      
      {/* Lesson Content */}
      <Card>
        <CardContent className="p-6">
          <div className="prose max-w-none">
            <p>{content.text}</p>
          </div>
          
          <Separator className="my-6" />
          
          {/* Question */}
          <div className="mt-4">
            <h3 className="font-medium text-lg mb-4">{question.question}</h3>
            
            {question.type === "multiple-choice" && (
              <div className="space-y-3">
                {question.options.map((option, index) => (
                  <div 
                    key={index}
                    className={`p-3 rounded-md border transition-colors cursor-pointer ${
                      selectedOption === index
                        ? "border-primary bg-primary/5"
                        : "border-neutral-200 hover:border-primary/50"
                    }`}
                    onClick={() => setSelectedOption(index)}
                  >
                    {option}
                  </div>
                ))}
              </div>
            )}
            
            <div className="mt-6">
              <Button 
                variant="outline" 
                onClick={() => setShowHint(!showHint)}
                className="text-neutral-700"
              >
                <Lightbulb className="mr-2 h-4 w-4" />
                {showHint ? "Hide Hint" : "Get Hint"}
              </Button>
              
              {showHint && (
                <div className="mt-3 p-4 bg-amber-50 rounded-md text-sm text-neutral-700 border border-amber-200">
                  <p><strong>Hint:</strong> {question.explanation}</p>
                </div>
              )}
            </div>
          </div>
          
          <div className="mt-6 flex justify-between">
            <Button variant="outline" disabled>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Previous
            </Button>
            <Button onClick={handleComplete} disabled={isPending}>
              {isPending ? "Saving..." : "Continue"}
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
