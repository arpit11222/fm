import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Lightbulb, Clock, Target, BarChart3, Trophy, PenTool } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";

export default function PracticePage() {
  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
  });

  const dailyStreak = user?.streak || 0;
  const userExp = user?.experience || 0;

  return (
    <div className="bg-black text-white">
      {/* Hero Section */}
      <div className="bg-black py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-3xl md:text-4xl font-bold mb-4">
                Daily Financial <span className="text-primary">Practice</span>
              </h1>
              <p className="text-lg text-neutral-400 mb-8">
                Strengthen your financial knowledge with daily exercises and keep your learning streak going.
              </p>
              <div className="flex justify-center gap-4 mb-8">
                <div className="flex items-center gap-2 px-4 py-2 bg-zinc-900 rounded-full border border-zinc-800">
                  <Lightbulb className="h-5 w-5 text-amber-500" />
                  <span className="text-white font-medium">{dailyStreak} day streak</span>
                </div>
                <div className="flex items-center gap-2 px-4 py-2 bg-zinc-900 rounded-full border border-zinc-800">
                  <Trophy className="h-5 w-5 text-amber-500" />
                  <span className="text-white font-medium">{userExp} XP total</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>

      {/* Daily Challenge */}
      <div className="py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Target className="h-6 w-6 text-primary" />
              Daily Challenge
            </h2>
            <p className="text-neutral-400">Complete today's exercises to maintain your streak</p>
          </div>

          <div className="bg-zinc-900 rounded-2xl border border-zinc-800 p-6 mb-10">
            <div className="flex flex-col md:flex-row gap-6 items-center mb-6">
              <div className="h-20 w-20 rounded-full bg-primary/20 flex items-center justify-center border border-primary/30">
                <PenTool className="h-10 w-10 text-primary" />
              </div>
              <div className="flex-1">
                <div className="flex flex-wrap gap-2 mb-2">
                  <Badge variant="outline" className="bg-primary/10 text-primary border-primary/20">
                    Personal Finance
                  </Badge>
                  <Badge variant="outline" className="bg-zinc-800 border-zinc-700">
                    <Clock className="h-3 w-3 mr-1" /> 5 min
                  </Badge>
                  <Badge variant="outline" className="bg-zinc-800 border-zinc-700">
                    <Trophy className="h-3 w-3 mr-1" /> 50 XP
                  </Badge>
                </div>
                <h3 className="text-xl font-bold mb-2">Budgeting Quiz: The 50/30/20 Rule</h3>
                <p className="text-neutral-400">
                  Test your understanding of the 50/30/20 budgeting rule with this quick quiz.
                </p>
              </div>
              <div>
                <Button size="lg" className="w-full md:w-auto">
                  Start Challenge
                </Button>
              </div>
            </div>
            <div>
              <div className="flex justify-between mb-2 text-sm">
                <span>Daily progress</span>
                <span>1 / 3 completed</span>
              </div>
              <Progress value={33} className="h-2" />
            </div>
          </div>
        </div>
      </div>

      {/* Practice Categories */}
      <div className="py-10 bg-zinc-900/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <BarChart3 className="h-6 w-6 text-primary" />
              Practice Categories
            </h2>
            <p className="text-neutral-400">Focus on specific areas to build targeted skills</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="bg-zinc-900 border-zinc-800 hover:border-primary/50 transition-colors">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2">
                  <div className="h-8 w-8 rounded-lg bg-blue-500/20 flex items-center justify-center">
                    <Lightbulb className="h-4 w-4 text-blue-400" />
                  </div>
                  Budgeting
                </CardTitle>
                <CardDescription>Create and manage effective budgets</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center text-sm mb-2">
                  <span className="text-neutral-400">Progress</span>
                  <span className="text-primary">20%</span>
                </div>
                <Progress value={20} className="h-1 mb-4" />
                <Button variant="outline" className="w-full">Practice Budgeting</Button>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800 hover:border-primary/50 transition-colors">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2">
                  <div className="h-8 w-8 rounded-lg bg-amber-500/20 flex items-center justify-center">
                    <Target className="h-4 w-4 text-amber-400" />
                  </div>
                  Investing
                </CardTitle>
                <CardDescription>Practice investing concepts and strategies</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center text-sm mb-2">
                  <span className="text-neutral-400">Progress</span>
                  <span className="text-primary">35%</span>
                </div>
                <Progress value={35} className="h-1 mb-4" />
                <Button variant="outline" className="w-full">Practice Investing</Button>
              </CardContent>
            </Card>

            <Card className="bg-zinc-900 border-zinc-800 hover:border-primary/50 transition-colors">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2">
                  <div className="h-8 w-8 rounded-lg bg-green-500/20 flex items-center justify-center">
                    <BarChart3 className="h-4 w-4 text-green-400" />
                  </div>
                  Financial Terms
                </CardTitle>
                <CardDescription>Learn and memorize key financial terminology</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center text-sm mb-2">
                  <span className="text-neutral-400">Progress</span>
                  <span className="text-primary">50%</span>
                </div>
                <Progress value={50} className="h-1 mb-4" />
                <Button variant="outline" className="w-full">Practice Terms</Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Flashcards */}
      <div className="py-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8">
            <h2 className="text-2xl font-bold mb-1">Quick Flashcards</h2>
            <p className="text-neutral-400">Test your knowledge with these financial flashcards</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="group perspective bg-zinc-900 border border-zinc-800 rounded-xl h-60 [transform-style:preserve-3d] transition-all duration-500 hover:[transform:rotateY(180deg)]">
              <div className="absolute inset-0 text-center flex flex-col items-center justify-center p-5 [backface-visibility:hidden]">
                <Lightbulb className="h-12 w-12 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-2">What is compound interest?</h3>
                <p className="text-sm text-neutral-400">Tap to reveal answer</p>
              </div>
              <div className="absolute inset-0 [transform:rotateY(180deg)] [backface-visibility:hidden] bg-primary/10 border border-primary/30 rounded-xl flex items-center justify-center p-5">
                <p>
                  Compound interest is when interest is earned on both the initial principal and the accumulated interest from previous periods.
                </p>
              </div>
            </div>

            <div className="group perspective bg-zinc-900 border border-zinc-800 rounded-xl h-60 [transform-style:preserve-3d] transition-all duration-500 hover:[transform:rotateY(180deg)]">
              <div className="absolute inset-0 text-center flex flex-col items-center justify-center p-5 [backface-visibility:hidden]">
                <Target className="h-12 w-12 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-2">What is a 401(k)?</h3>
                <p className="text-sm text-neutral-400">Tap to reveal answer</p>
              </div>
              <div className="absolute inset-0 [transform:rotateY(180deg)] [backface-visibility:hidden] bg-primary/10 border border-primary/30 rounded-xl flex items-center justify-center p-5">
                <p>
                  A 401(k) is a retirement savings plan sponsored by an employer that allows workers to save and invest a portion of their paycheck before taxes are taken out.
                </p>
              </div>
            </div>

            <div className="group perspective bg-zinc-900 border border-zinc-800 rounded-xl h-60 [transform-style:preserve-3d] transition-all duration-500 hover:[transform:rotateY(180deg)]">
              <div className="absolute inset-0 text-center flex flex-col items-center justify-center p-5 [backface-visibility:hidden]">
                <BarChart3 className="h-12 w-12 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-2">What is dollar-cost averaging?</h3>
                <p className="text-sm text-neutral-400">Tap to reveal answer</p>
              </div>
              <div className="absolute inset-0 [transform:rotateY(180deg)] [backface-visibility:hidden] bg-primary/10 border border-primary/30 rounded-xl flex items-center justify-center p-5">
                <p>
                  Dollar-cost averaging is an investment strategy where a fixed amount of money is invested in a particular security at regular intervals, regardless of price.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}