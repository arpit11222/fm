import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { LessonModal } from "@/components/LessonModal";
import { getFinanceIcon } from "@/lib/finance-icons";
import { BookOpen, CheckCircle, ChevronRight, LockIcon } from "lucide-react";

export default function CoursePage() {
  const [, params] = useRoute("/course/:id");
  const courseId = parseInt(params?.id || "0");
  
  const [selectedLesson, setSelectedLesson] = useState<number | null>(null);
  
  // Fetch course details
  const { data: course, isLoading: courseLoading } = useQuery({
    queryKey: [`/api/courses/${courseId}`],
  });
  
  // Fetch lessons for this course
  const { data: lessons, isLoading: lessonsLoading } = useQuery({
    queryKey: [`/api/courses/${courseId}/lessons`],
  });
  
  // Fetch user progress for this course
  const { data: courseProgress, isLoading: progressLoading } = useQuery({
    queryKey: [`/api/progress/course/${courseId}`],
  });
  
  const isLoading = courseLoading || lessonsLoading || progressLoading;
  
  if (isLoading) {
    return (
      <div className="container max-w-4xl mx-auto py-8 px-4">
        <div className="animate-pulse">
          <div className="h-10 bg-gray-200 rounded w-3/4 mb-4"></div>
          <div className="h-6 bg-gray-200 rounded w-1/2 mb-8"></div>
          <div className="h-4 bg-gray-200 rounded w-full mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-5/6 mb-6"></div>
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-24 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }
  
  if (!course) {
    return (
      <div className="container max-w-4xl mx-auto py-8 px-4">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Course not found</h1>
          <p className="mb-4">The course you're looking for doesn't exist.</p>
          <Link href="/">
            <Button>Back to Home</Button>
          </Link>
        </div>
      </div>
    );
  }
  
  const Icon = getFinanceIcon(course.iconName);
  const progressPercentage = courseProgress?.progress || 0;
  
  const handleOpenLesson = (lessonId: number) => {
    setSelectedLesson(lessonId);
  };
  
  const handleCloseLesson = () => {
    setSelectedLesson(null);
  };
  
  const currentLesson = lessons?.find(lesson => lesson.id === selectedLesson);
  
  return (
    <div className="container max-w-4xl mx-auto py-8 px-4">
      {/* Course Header */}
      <div className="mb-8">
        <div className="flex items-center mb-4">
          <div className="bg-primary bg-opacity-20 p-3 rounded-full mr-4">
            <Icon className="text-primary h-6 w-6" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">{course.name}</h1>
            <p className="text-neutral-600">{course.description}</p>
          </div>
        </div>
        
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-4">
            <div className="text-sm text-neutral-600 flex items-center">
              <BookOpen className="h-4 w-4 mr-1" />
              {course.category}
            </div>
            <div className="text-sm text-neutral-600">
              {course.difficulty} Level
            </div>
            <div className="text-sm text-neutral-600">
              {course.duration}
            </div>
          </div>
          <div className="text-sm font-medium text-primary">
            {course.xpReward} XP upon completion
          </div>
        </div>
        
        <div className="mt-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-neutral-600">Course Progress</span>
            <span className="text-sm font-medium text-primary">{progressPercentage}%</span>
          </div>
          <Progress value={progressPercentage} className="h-2.5" />
        </div>
      </div>
      
      {/* Lessons List */}
      <div className="space-y-4">
        <h2 className="text-xl font-bold mb-4">Lessons</h2>
        
        {lessons?.map((lesson, index) => {
          const isCompleted = false; // In a real app, fetch from API
          const isLocked = index > 0 && !isCompleted; // Lock future lessons
          
          return (
            <Card key={lesson.id} className="overflow-hidden">
              <CardContent className="p-0">
                <div className={`p-4 flex justify-between items-center ${isCompleted ? "bg-green-50" : ""}`}>
                  <div className="flex items-center">
                    <div className="bg-neutral-100 rounded-full w-8 h-8 flex items-center justify-center mr-4">
                      <span className="font-medium text-sm">{index + 1}</span>
                    </div>
                    <div>
                      <h3 className="font-medium">{lesson.title}</h3>
                      <p className="text-sm text-neutral-600">{lesson.description}</p>
                    </div>
                  </div>
                  
                  <div>
                    {isCompleted ? (
                      <div className="flex items-center text-green-600">
                        <CheckCircle className="h-5 w-5 mr-1" />
                        <span className="text-sm font-medium">Completed</span>
                      </div>
                    ) : isLocked ? (
                      <div className="flex items-center text-neutral-400">
                        <LockIcon className="h-5 w-5 mr-1" />
                        <span className="text-sm font-medium">Locked</span>
                      </div>
                    ) : (
                      <Button 
                        onClick={() => handleOpenLesson(lesson.id)}
                        className="flex items-center"
                      >
                        <span>Start</span>
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
      
      {/* Course Prerequisites */}
      {course.prerequisiteIds && course.prerequisiteIds.length > 0 && (
        <div className="mt-8">
          <h2 className="text-xl font-bold mb-4">Prerequisites</h2>
          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm text-blue-800">
              This course requires completing the following courses first:
            </p>
            <ul className="list-disc list-inside mt-2 text-sm text-blue-800">
              {course.prerequisiteIds.map((prereqId) => (
                <li key={prereqId}>
                  <Link href={`/course/${prereqId}`}>
                    <a className="underline hover:text-blue-600">
                      Course #{prereqId}
                    </a>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}
      
      {/* Back to Dashboard */}
      <div className="mt-8 text-center">
        <Link href="/">
          <Button variant="outline">
            Back to Dashboard
          </Button>
        </Link>
      </div>
      
      {/* Lesson Modal */}
      {currentLesson && (
        <LessonModal
          lesson={currentLesson}
          isOpen={!!selectedLesson}
          onClose={handleCloseLesson}
          currentStep={1}
          totalSteps={5}
        />
      )}
    </div>
  );
}
