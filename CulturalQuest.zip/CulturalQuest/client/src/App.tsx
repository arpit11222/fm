import { Switch, Route, Redirect } from "wouter";
import NotFound from "@/pages/not-found";
import HomePage from "@/pages/HomePage";
import AuthPage from "@/pages/auth-page";
import CoursePage from "@/pages/CoursePage";
import CoursesPage from "@/pages/CoursesPage";
import LessonPage from "@/pages/LessonPage";
import Achievements from "@/pages/Achievements";
import PracticePage from "@/pages/PracticePage";
import AnalyticsPage from "@/pages/AnalyticsPage";
import ResourcesPage from "@/pages/ResourcesPage";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2 } from "lucide-react";

// ProtectedRoute component to handle auth checks
function ProtectedRoute({ 
  component: Component, 
  ...rest 
}: { 
  component: () => React.JSX.Element,
  path: string 
}) {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!user) {
    return <Redirect to="/auth" />;
  }

  return <Component />;
}

function App() {
  const { isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow">
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/auth" component={AuthPage} />
          
          {/* Protected Routes */}
          <ProtectedRoute path="/courses" component={CoursesPage} />
          <ProtectedRoute path="/practice" component={PracticePage} />
          <ProtectedRoute path="/analytics" component={AnalyticsPage} />
          <ProtectedRoute path="/achievements" component={Achievements} />
          <ProtectedRoute path="/resources/:tab?" component={ResourcesPage} />
          <ProtectedRoute path="/course/:id" component={CoursePage} />
          <ProtectedRoute path="/lesson/:id" component={LessonPage} />
          
          {/* Fallback to 404 */}
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </div>
  );
}

export default App;
