import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Card } from "@/components/ui/card";
import { Course, UserProgress } from "@shared/schema";
import { motion } from "framer-motion";

interface SkillTreeProps {
  courses: Course[];
  progress: UserProgress[];
}

interface SkillNode {
  id: number;
  name: string;
  x: number;
  y: number;
  completed: boolean;
  inProgress: boolean;
  locked: boolean;
}

interface SkillConnection {
  from: number;
  to: number;
  completed: boolean;
}

export function SkillTree({ courses, progress }: SkillTreeProps) {
  const [nodes, setNodes] = useState<SkillNode[]>([]);
  const [connections, setConnections] = useState<SkillConnection[]>([]);
  
  useEffect(() => {
    if (courses.length === 0) return;
    
    // Transform courses into skill nodes
    const layoutMap: Record<number, { x: number, y: number }> = {
      1: { x: 140, y: 175 }, // Financial Basics
      2: { x: 320, y: 175 }, // Budgeting 101
      4: { x: 320, y: 100 }, // Investing Basics
      3: { x: 320, y: 250 }, // Debt Management
      5: { x: 560, y: 100 }, // Stock Market
      6: { x: 560, y: 175 }, // Saving Strategies
      7: { x: 560, y: 250 }, // Credit Score
      8: { x: 740, y: 175 }, // Financial Freedom
    };
    
    const processedNodes: SkillNode[] = courses.map(course => {
      // Find course progress
      const courseProgress = progress.find(p => p.courseId === course.id && !p.lessonId);
      const isCompleted = courseProgress?.completed || false;
      const isInProgress = courseProgress && !isCompleted ? true : false;
      
      // Determine if locked (prerequisites not met)
      const prerequisites = course.prerequisiteIds || [];
      const prereqsMet = prerequisites.length === 0 || 
        prerequisites.every(prereqId => {
          const prereqProgress = progress.find(p => p.courseId === prereqId && !p.lessonId);
          return prereqProgress?.completed || false;
        });
      
      // Get position from layout map or default
      const position = layoutMap[course.id] || { x: 100 + (course.id * 100), y: 175 };
      
      return {
        id: course.id,
        name: course.name,
        x: position.x,
        y: position.y,
        completed: isCompleted,
        inProgress: isInProgress,
        locked: !prereqsMet && !isCompleted && !isInProgress
      };
    });
    
    setNodes(processedNodes);
    
    // Generate connections
    const processedConnections: SkillConnection[] = [];
    courses.forEach(course => {
      const prereqs = course.prerequisiteIds || [];
      prereqs.forEach(prereqId => {
        // Find if the prerequisite is completed
        const prereqProgress = progress.find(p => p.courseId === prereqId && !p.lessonId);
        const isCompleted = prereqProgress?.completed || false;
        
        processedConnections.push({
          from: prereqId,
          to: course.id,
          completed: isCompleted
        });
      });
    });
    
    setConnections(processedConnections);
  }, [courses, progress]);
  
  if (nodes.length === 0) {
    return <div className="mt-6 text-center py-8">Loading skill tree...</div>;
  }
  
  return (
    <div className="mt-6 overflow-x-auto">
      <div className="min-w-[800px]">
        <svg width="100%" height="350" viewBox="0 0 800 350">
          {/* Connector Lines */}
          {connections.map((connection, index) => {
            const fromNode = nodes.find(n => n.id === connection.from);
            const toNode = nodes.find(n => n.id === connection.to);
            
            if (!fromNode || !toNode) return null;
            
            return (
              <line 
                key={`${connection.from}-${connection.to}`}
                x1={fromNode.x} 
                y1={fromNode.y} 
                x2={toNode.x} 
                y2={toNode.y} 
                className={`transition-all duration-500 ${
                  connection.completed 
                    ? "stroke-primary" 
                    : "stroke-neutral-200"
                }`} 
                strokeWidth="2"
              />
            );
          })}
          
          {/* Skill Nodes */}
          {nodes.map((node) => (
            <Link href={`/course/${node.id}`} key={node.id}>
              <a>
                <motion.g 
                  className="cursor-pointer"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.3 }}
                >
                  <circle cx={node.x} cy={node.y} r="40" fill={node.completed ? "#4CAF50" : "#1976D2"} />
                  <circle cx={node.x} cy={node.y} r="35" fill="white" />
                  <circle 
                    cx={node.x} 
                    cy={node.y} 
                    r="30" 
                    fill={
                      node.completed 
                        ? "#4CAF50" 
                        : node.inProgress 
                          ? "#1976D2" 
                          : "#E0E0E0"
                    } 
                  />
                  <text 
                    x={node.x} 
                    y={node.y} 
                    fontSize="12" 
                    fill={node.locked ? "#616161" : "white"} 
                    textAnchor="middle" 
                    dominantBaseline="middle" 
                    fontFamily="Poppins"
                  >
                    {node.name.split(' ').map((word, i, arr) => (
                      <tspan 
                        key={i} 
                        x={node.x} 
                        y={node.y + (i - arr.length / 2 + 0.5) * 15}
                      >
                        {word}
                      </tspan>
                    ))}
                  </text>
                  <circle 
                    cx={node.x} 
                    cy={node.y} 
                    r="40" 
                    fill="transparent" 
                    stroke={
                      node.completed 
                        ? "#4CAF50" 
                        : node.inProgress 
                          ? "#1976D2" 
                          : "#E0E0E0"
                    } 
                    strokeWidth="2" 
                  />
                  
                  {node.locked && (
                    <circle 
                      cx={node.x + 25} 
                      cy={node.y - 25} 
                      r="12" 
                      fill="#616161"
                    >
                      <title>Locked - Complete prerequisites first</title>
                    </circle>
                  )}
                  
                  {node.locked && (
                    <text 
                      x={node.x + 25} 
                      y={node.y - 25} 
                      fontSize="10" 
                      fill="white" 
                      textAnchor="middle" 
                      dominantBaseline="middle"
                    >
                      <tspan x={node.x + 25} y={node.y - 25}>🔒</tspan>
                    </text>
                  )}
                </motion.g>
              </a>
            </Link>
          ))}
        </svg>
      </div>
    </div>
  );
}
