import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Course } from "@shared/schema";
import { BookOpen, Clock } from "lucide-react";
import { getFinanceIcon } from "@/lib/finance-icons";

interface CourseCardProps {
  course: Course;
  progress: number;
  detailView?: boolean;
}

export function CourseCard({ course, progress, detailView = false }: CourseCardProps) {
  const Icon = getFinanceIcon(course.iconName);
  
  if (detailView) {
    return (
      <Card className="bg-white rounded-xl shadow-md overflow-hidden transition-transform hover:translate-y-[-5px]">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row md:items-center">
            <div className="flex-shrink-0 mb-4 md:mb-0 md:mr-6">
              <div className="w-16 h-16 bg-primary bg-opacity-20 rounded-xl flex items-center justify-center">
                <Icon className="text-primary text-2xl h-8 w-8" />
              </div>
            </div>
            
            <div className="flex-grow">
              <h3 className="font-semibold text-lg text-neutral-800">{course.name}: {course.description}</h3>
              <p className="text-neutral-600 mt-2">
                Learn how to track expenses, set financial goals, and create a sustainable budget.
              </p>
              
              <div className="mt-4">
                <div className="flex items-center">
                  <div className="text-sm text-neutral-500">
                    <span className="font-medium text-primary">{progress}% complete</span> • Lesson 3 of 5
                  </div>
                </div>
                <Progress className="mt-2 h-2.5" value={progress} />
              </div>
              
              <div className="mt-6 flex flex-col sm:flex-row items-center gap-4">
                <Link href={`/course/${course.id}`}>
                  <Button className="w-full sm:w-auto">
                    Continue Learning
                  </Button>
                </Link>
                <Link href={`/course/${course.id}`}>
                  <Button variant="outline" className="w-full sm:w-auto">
                    View Course Overview
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white rounded-xl shadow-md overflow-hidden transition-transform hover:translate-y-[-5px]">
      <CardContent className="p-5">
        <div className="flex items-center mb-4">
          <div className="p-3 bg-primary bg-opacity-20 rounded-full">
            <Icon className="text-primary h-5 w-5" />
          </div>
          <h3 className="ml-3 font-semibold text-neutral-800">{course.name}</h3>
        </div>
        <p className="text-neutral-600 text-sm">{course.description}</p>
        <div className="mt-4 flex items-center text-sm">
          <BookOpen className="h-4 w-4 text-neutral-500 mr-2" />
          <span className="text-neutral-500">{course.category}</span>
          <span className="mx-2 text-neutral-300">•</span>
          <Clock className="h-4 w-4 text-neutral-500 mr-2" />
          <span className="text-neutral-500">{course.duration}</span>
        </div>
        <Link href={`/course/${course.id}`}>
          <Button className="mt-4 w-full" variant="outline">
            {progress > 0 ? "Continue Course" : "Start Course"}
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
