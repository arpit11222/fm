import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { Progress } from "@/components/ui/progress";
import { SkillTree } from "@/components/SkillTree";
import { CourseCard } from "@/components/CourseCard";
import { AchievementBadge } from "@/components/AchievementBadge";
import { Award, ChartPie, Flame, Gem } from "lucide-react";
import useMobile from "@/hooks/use-mobile";

export default function Dashboard() {
  const { user } = useAuth();
  const isMobile = useMobile();
  
  const { data: courses, isLoading: coursesLoading } = useQuery({
    queryKey: ["/api/courses"],
  });
  
  const { data: progress, isLoading: progressLoading } = useQuery({
    queryKey: ["/api/progress"],
  });
  
  const { data: achievements, isLoading: achievementsLoading } = useQuery({
    queryKey: ["/api/achievements/user"],
  });
  
  // Calculate daily goal progress (Mock logic - would be from actual user progress)
  const dailyGoalXP = 50;
  const dailyGoalProgress = Math.min(100, Math.round((user?.experience % dailyGoalXP) / dailyGoalXP * 100));
  const xpToComplete = dailyGoalXP - (user?.experience % dailyGoalXP);
  
  // Current course
  const currentCourse = courses?.find(c => c.id === 2); // ID for Budgeting 101
  const courseProgress = progress?.find(p => p.courseId === currentCourse?.id && !p.lessonId);
  const courseProgressPercent = courseProgress ? courseProgress.progress : 65; // Default to 65% as fallback
  
  return (
    <div>
      {/* Dashboard Header */}
      <div className="bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between">
            <div>
              <h1 className="text-2xl font-bold">Welcome back, {user?.displayName?.split(' ')[0] || "User"}!</h1>
              <p className="mt-1 text-white text-opacity-80">Continue your financial learning journey</p>
            </div>
            <div className="mt-4 md:mt-0">
              <Link href={currentCourse ? `/course/${currentCourse.id}` : "/"}>
                <Button className="bg-white text-primary hover:bg-neutral-100 px-6">
                  Start Today's Lesson
                </Button>
              </Link>
            </div>
          </div>
          
          {/* Progress Cards */}
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Daily Goal */}
            <Card className="bg-white rounded-xl shadow-md transition-transform hover:translate-y-[-5px]">
              <CardContent className="p-4">
                <div className="flex items-center">
                  <div className="bg-amber-100 p-3 rounded-full">
                    <Award className="text-amber-500 h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <h3 className="font-medium text-neutral-800">Daily Goal</h3>
                    <Progress className="mt-2 h-2.5" value={dailyGoalProgress} />
                    <p className="text-sm text-neutral-600 mt-1">{xpToComplete} XP more to complete</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Streak */}
            <Card className="bg-white rounded-xl shadow-md transition-transform hover:translate-y-[-5px]">
              <CardContent className="p-4">
                <div className="flex items-center">
                  <div className="bg-primary bg-opacity-20 p-3 rounded-full">
                    <Flame className="text-primary h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <h3 className="font-medium text-neutral-800">Current Streak</h3>
                    <p className="text-3xl font-bold text-primary mt-1">{user?.streak || 0} Days</p>
                    <p className="text-sm text-neutral-600">Best: 14 days</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            {/* Total XP */}
            <Card className="bg-white rounded-xl shadow-md transition-transform hover:translate-y-[-5px]">
              <CardContent className="p-4">
                <div className="flex items-center">
                  <div className="bg-blue-100 p-3 rounded-full">
                    <Gem className="text-blue-600 h-6 w-6" />
                  </div>
                  <div className="ml-4">
                    <h3 className="font-medium text-neutral-800">Total XP</h3>
                    <p className="text-3xl font-bold text-blue-600 mt-1">{user?.experience || 0}</p>
                    <p className="text-sm text-neutral-600">Level {user?.level || 1} Investor</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
      
      {/* Learning Path */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <h2 className="text-xl font-bold text-neutral-800">Your Learning Path</h2>
        
        {/* Skill Tree (Desktop) / Course Cards (Mobile) */}
        {isMobile ? (
          <div className="mt-6 grid grid-cols-1 gap-4">
            {coursesLoading ? (
              <div className="text-center py-4">Loading...</div>
            ) : (
              courses?.map((course) => (
                <Card key={course.id} className="bg-white rounded-xl shadow-md border-l-4 border-primary">
                  <CardContent className="p-4">
                    <div className="flex items-center">
                      <div className="bg-primary bg-opacity-20 p-3 rounded-full">
                        <ChartPie className="text-primary h-5 w-5" />
                      </div>
                      <div className="ml-4 flex-grow">
                        <div className="flex justify-between items-center">
                          <h3 className="font-medium text-neutral-800">{course.name}</h3>
                          <span className="text-xs bg-primary text-white px-2 py-1 rounded-full">
                            {course.id === 1 ? "Completed" : course.id === 2 ? "In Progress" : "Locked"}
                          </span>
                        </div>
                        <Progress 
                          className="mt-2 h-2" 
                          value={course.id === 1 ? 100 : course.id === 2 ? courseProgressPercent : 0} 
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        ) : (
          <SkillTree courses={courses || []} progress={progress || []} />
        )}
        
        {/* Continue Learning */}
        <div className="mt-12">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold text-neutral-800">Continue Learning</h2>
            <Link href="/">
              <a className="text-blue-600 hover:underline text-sm font-medium">View All Courses</a>
            </Link>
          </div>
          
          {/* Current Course */}
          {currentCourse && (
            <div className="mt-4">
              <CourseCard 
                course={currentCourse}
                progress={courseProgressPercent}
                detailView={true}
              />
            </div>
          )}
        </div>
        
        {/* Course Categories */}
        <div className="mt-12">
          <h2 className="text-xl font-bold text-neutral-800">Financial Course Categories</h2>
          
          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Personal Finance */}
            <Card className="bg-white rounded-xl shadow-md overflow-hidden transition-transform hover:translate-y-[-5px]">
              <CardContent className="p-5">
                <div className="flex items-center mb-4">
                  <div className="p-3 bg-primary bg-opacity-20 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-primary">
                      <path d="M20.2 7.8l-7.7 7.7-4-4-5.7 5.7" />
                      <path d="M15 7h6v6" />
                    </svg>
                  </div>
                  <h3 className="ml-3 font-semibold text-neutral-800">Personal Finance</h3>
                </div>
                <p className="text-neutral-600 text-sm">Master budgeting, savings, and debt management fundamentals.</p>
                <div className="mt-4 flex items-center text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-neutral-500 mr-2">
                    <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20" />
                  </svg>
                  <span className="text-neutral-500">4 courses</span>
                  <span className="mx-2 text-neutral-300">•</span>
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-neutral-500 mr-2">
                    <circle cx="12" cy="12" r="10" />
                    <polyline points="12 6 12 12 16 14" />
                  </svg>
                  <span className="text-neutral-500">8-10 hours</span>
                </div>
                <Button className="mt-4 w-full" variant="outline">
                  Browse Courses
                </Button>
              </CardContent>
            </Card>
            
            {/* Investing */}
            <Card className="bg-white rounded-xl shadow-md overflow-hidden transition-transform hover:translate-y-[-5px]">
              <CardContent className="p-5">
                <div className="flex items-center mb-4">
                  <div className="p-3 bg-blue-100 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-blue-600">
                      <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
                    </svg>
                  </div>
                  <h3 className="ml-3 font-semibold text-neutral-800">Investing</h3>
                </div>
                <p className="text-neutral-600 text-sm">Learn about stocks, bonds, funds, and real estate investments.</p>
                <div className="mt-4 flex items-center text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-neutral-500 mr-2">
                    <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20" />
                  </svg>
                  <span className="text-neutral-500">6 courses</span>
                  <span className="mx-2 text-neutral-300">•</span>
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-neutral-500 mr-2">
                    <circle cx="12" cy="12" r="10" />
                    <polyline points="12 6 12 12 16 14" />
                  </svg>
                  <span className="text-neutral-500">12-15 hours</span>
                </div>
                <Button className="mt-4 w-full text-blue-600 border-blue-600" variant="outline">
                  Browse Courses
                </Button>
              </CardContent>
            </Card>
            
            {/* Banking */}
            <Card className="bg-white rounded-xl shadow-md overflow-hidden transition-transform hover:translate-y-[-5px]">
              <CardContent className="p-5">
                <div className="flex items-center mb-4">
                  <div className="p-3 bg-blue-100 bg-opacity-50 rounded-full">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-5 w-5 text-blue-500">
                      <rect x="3" y="8" width="18" height="12" rx="2" />
                      <path d="M7 6v4" />
                      <path d="M17 6v4" />
                      <path d="M15 14h.01" />
                      <path d="M11 14h.01" />
                      <path d="M7 14h.01" />
                      <path d="M15 18h.01" />
                      <path d="M11 18h.01" />
                      <path d="M7 18h.01" />
                    </svg>
                  </div>
                  <h3 className="ml-3 font-semibold text-neutral-800">Banking</h3>
                </div>
                <p className="text-neutral-600 text-sm">Understand accounts, loans, credit, and banking services.</p>
                <div className="mt-4 flex items-center text-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-neutral-500 mr-2">
                    <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20" />
                  </svg>
                  <span className="text-neutral-500">3 courses</span>
                  <span className="mx-2 text-neutral-300">•</span>
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4 text-neutral-500 mr-2">
                    <circle cx="12" cy="12" r="10" />
                    <polyline points="12 6 12 12 16 14" />
                  </svg>
                  <span className="text-neutral-500">5-7 hours</span>
                </div>
                <Button className="mt-4 w-full text-blue-500 border-blue-500" variant="outline">
                  Browse Courses
                </Button>
              </CardContent>
            </Card>
          </div>
          
          <div className="mt-6 text-center">
            <Button variant="link" className="text-blue-600">
              View All Categories
            </Button>
          </div>
        </div>
        
        {/* Recent Achievements */}
        <div className="mt-12">
          <h2 className="text-xl font-bold text-neutral-800">Your Recent Achievements</h2>
          
          <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-4">
            {achievementsLoading ? (
              <div className="col-span-4 text-center py-4">Loading...</div>
            ) : achievements && achievements.length > 0 ? (
              // Map through actual user achievements
              achievements.slice(0, 3).map((userAchievement) => (
                <AchievementBadge
                  key={userAchievement.id}
                  name={userAchievement.achievement.name}
                  iconName={userAchievement.achievement.iconName}
                  earnedDate={new Date(userAchievement.earnedAt)}
                  isNew={false}
                />
              ))
            ) : (
              // If no achievements, show some locked ones
              <>
                <AchievementBadge
                  name="Budgeting Master"
                  iconName="money-box"
                  locked={false}
                  earnedDate={new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)}
                />
                <AchievementBadge
                  name="7 Day Streak"
                  iconName="fire-element"
                  locked={false}
                  earnedDate={new Date()}
                  isNew={true}
                />
                <AchievementBadge
                  name="Quiz Whiz"
                  iconName="quiz"
                  locked={false}
                  earnedDate={new Date(Date.now() - 5 * 24 * 60 * 60 * 1000)}
                />
                <AchievementBadge
                  name="Budget Champion"
                  iconName="trophy"
                  locked={true}
                  requirement="Complete 5 budget lessons"
                />
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
