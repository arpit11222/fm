import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, PieChart, Plus, DollarSign, Trash2, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface BudgetPlannerProps {
  onBack: () => void;
}

interface ExpenseItem {
  id: string;
  category: string;
  amount: number;
}

interface IncomeItem {
  id: string;
  source: string;
  amount: number;
}

export function BudgetPlanner({ onBack }: BudgetPlannerProps) {
  const { toast } = useToast();
  const [income, setIncome] = useState<IncomeItem[]>([
    { id: "1", source: "Salary", amount: 3000 },
    { id: "2", source: "Side Hustle", amount: 500 },
  ]);
  
  const [expenses, setExpenses] = useState<ExpenseItem[]>([
    { id: "1", category: "Housing", amount: 1200 },
    { id: "2", category: "Food", amount: 400 },
    { id: "3", category: "Transportation", amount: 200 },
    { id: "4", category: "Entertainment", amount: 150 },
    { id: "5", category: "Utilities", amount: 250 },
  ]);
  
  const [newIncome, setNewIncome] = useState({ source: "", amount: 0 });
  const [newExpense, setNewExpense] = useState({ category: "", amount: 0 });
  
  const totalIncome = income.reduce((sum, item) => sum + item.amount, 0);
  const totalExpenses = expenses.reduce((sum, item) => sum + item.amount, 0);
  const balance = totalIncome - totalExpenses;
  
  const addIncomeItem = () => {
    if (!newIncome.source || newIncome.amount <= 0) {
      toast({
        title: "Invalid input",
        description: "Please provide a valid income source and amount",
        variant: "destructive",
      });
      return;
    }
    
    setIncome([...income, { 
      id: `income-${Date.now()}`, 
      source: newIncome.source, 
      amount: newIncome.amount 
    }]);
    setNewIncome({ source: "", amount: 0 });
  };
  
  const addExpenseItem = () => {
    if (!newExpense.category || newExpense.amount <= 0) {
      toast({
        title: "Invalid input",
        description: "Please provide a valid expense category and amount",
        variant: "destructive",
      });
      return;
    }
    
    setExpenses([...expenses, { 
      id: `expense-${Date.now()}`, 
      category: newExpense.category, 
      amount: newExpense.amount 
    }]);
    setNewExpense({ category: "", amount: 0 });
  };
  
  const removeIncomeItem = (id: string) => {
    setIncome(income.filter(item => item.id !== id));
  };
  
  const removeExpenseItem = (id: string) => {
    setExpenses(expenses.filter(item => item.id !== id));
  };
  
  const saveBudget = () => {
    toast({
      title: "Budget saved",
      description: "Your budget has been saved successfully.",
    });
  };
  
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);
  };
  
  const calculateExpensePercentage = (amount: number) => {
    return totalExpenses ? (amount / totalExpenses) * 100 : 0;
  };

  return (
    <div className="max-w-6xl mx-auto">
      <Button 
        variant="ghost" 
        className="mb-6 hover:bg-zinc-800" 
        onClick={onBack}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Tools
      </Button>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Income Section */}
          <Card className="bg-zinc-900 border-zinc-800 shadow-lg">
            <CardHeader>
              <CardTitle className="text-green-400 flex items-center">
                <DollarSign className="mr-2 h-5 w-5" />
                Income
              </CardTitle>
              <CardDescription>Track all your income sources</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-12 gap-4">
                  <div className="col-span-6">
                    <Label htmlFor="income-source">Source</Label>
                    <Input
                      id="income-source"
                      placeholder="e.g., Salary, Freelance"
                      value={newIncome.source}
                      onChange={(e) => setNewIncome({ ...newIncome, source: e.target.value })}
                      className="bg-zinc-800 border-zinc-700"
                    />
                  </div>
                  <div className="col-span-4">
                    <Label htmlFor="income-amount">Amount</Label>
                    <div className="relative">
                      <DollarSign className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="income-amount"
                        type="number"
                        placeholder="Amount"
                        value={newIncome.amount || ""}
                        onChange={(e) => setNewIncome({ ...newIncome, amount: Number(e.target.value) })}
                        className="pl-9 bg-zinc-800 border-zinc-700"
                      />
                    </div>
                  </div>
                  <div className="col-span-2 flex items-end">
                    <Button 
                      onClick={addIncomeItem}
                      className="w-full bg-green-600 hover:bg-green-700"
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2 max-h-64 overflow-y-auto pr-2">
                  {income.map((item) => (
                    <div 
                      key={item.id} 
                      className="grid grid-cols-12 gap-4 p-3 rounded-md bg-zinc-800 items-center"
                    >
                      <div className="col-span-6 font-medium">{item.source}</div>
                      <div className="col-span-4 text-green-400">{formatCurrency(item.amount)}</div>
                      <div className="col-span-2 flex justify-end">
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="text-red-400 hover:text-red-300 hover:bg-red-900/20 h-8 w-8 p-0"
                          onClick={() => removeIncomeItem(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Expenses Section */}
          <Card className="bg-zinc-900 border-zinc-800 shadow-lg">
            <CardHeader>
              <CardTitle className="text-amber-400 flex items-center">
                <PieChart className="mr-2 h-5 w-5" />
                Expenses
              </CardTitle>
              <CardDescription>Manage your spending categories</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-12 gap-4">
                  <div className="col-span-6">
                    <Label htmlFor="expense-category">Category</Label>
                    <Input
                      id="expense-category"
                      placeholder="e.g., Rent, Groceries"
                      value={newExpense.category}
                      onChange={(e) => setNewExpense({ ...newExpense, category: e.target.value })}
                      className="bg-zinc-800 border-zinc-700"
                    />
                  </div>
                  <div className="col-span-4">
                    <Label htmlFor="expense-amount">Amount</Label>
                    <div className="relative">
                      <DollarSign className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                      <Input
                        id="expense-amount"
                        type="number"
                        placeholder="Amount"
                        value={newExpense.amount || ""}
                        onChange={(e) => setNewExpense({ ...newExpense, amount: Number(e.target.value) })}
                        className="pl-9 bg-zinc-800 border-zinc-700"
                      />
                    </div>
                  </div>
                  <div className="col-span-2 flex items-end">
                    <Button 
                      onClick={addExpenseItem}
                      className="w-full bg-amber-600 hover:bg-amber-700"
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2 max-h-64 overflow-y-auto pr-2">
                  {expenses.map((item) => (
                    <div 
                      key={item.id} 
                      className="grid grid-cols-12 gap-4 p-3 rounded-md bg-zinc-800 items-center"
                    >
                      <div className="col-span-6 font-medium">{item.category}</div>
                      <div className="col-span-4 text-amber-400">{formatCurrency(item.amount)}</div>
                      <div className="col-span-2 flex justify-end">
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          className="text-red-400 hover:text-red-300 hover:bg-red-900/20 h-8 w-8 p-0"
                          onClick={() => removeExpenseItem(item.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Summary Section */}
        <div>
          <Card className="bg-zinc-900 border-zinc-800 shadow-lg sticky top-6">
            <CardHeader>
              <CardTitle>Budget Summary</CardTitle>
              <CardDescription>Overview of your finances</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20">
                  <h4 className="text-sm font-medium text-neutral-400 mb-1">Total Income</h4>
                  <p className="text-2xl font-bold text-green-400">{formatCurrency(totalIncome)}</p>
                </div>
                
                <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/20">
                  <h4 className="text-sm font-medium text-neutral-400 mb-1">Total Expenses</h4>
                  <p className="text-2xl font-bold text-amber-400">{formatCurrency(totalExpenses)}</p>
                </div>
                
                <div className={`p-4 rounded-lg ${
                  balance >= 0 
                    ? "bg-primary/10 border border-primary/20" 
                    : "bg-red-500/10 border border-red-500/20"
                }`}>
                  <h4 className="text-sm font-medium text-neutral-400 mb-1">Balance</h4>
                  <p className={`text-2xl font-bold ${
                    balance >= 0 ? "text-primary" : "text-red-400"
                  }`}>
                    {formatCurrency(balance)}
                  </p>
                </div>
              </div>
              
              {/* Expense Breakdown */}
              {expenses.length > 0 && (
                <div>
                  <h4 className="text-sm font-medium text-neutral-400 mb-3">Expense Breakdown</h4>
                  <div className="space-y-2">
                    {expenses.map((expense) => (
                      <div key={expense.id} className="space-y-1">
                        <div className="flex justify-between text-sm">
                          <span>{expense.category}</span>
                          <span className="text-amber-400">{formatCurrency(expense.amount)}</span>
                        </div>
                        <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-gradient-to-r from-amber-400 to-amber-500" 
                            style={{ width: `${calculateExpensePercentage(expense.amount)}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button 
                onClick={saveBudget} 
                className="w-full"
                variant="outline"
              >
                <Save className="mr-2 h-4 w-4" />
                Save Budget
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}