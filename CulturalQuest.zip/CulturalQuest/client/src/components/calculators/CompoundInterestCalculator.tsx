import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Calculator, Coins, Calendar, DollarSign, TrendingUp } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLocation } from "wouter";

interface CompoundInterestCalculatorProps {
  onBack: () => void;
}

export function CompoundInterestCalculator({ onBack }: CompoundInterestCalculatorProps) {
  const [principal, setPrincipal] = useState<number>(1000);
  const [rate, setRate] = useState<number>(5);
  const [time, setTime] = useState<number>(10);
  const [compoundFrequency, setCompoundFrequency] = useState<string>("yearly");
  const [additionalContribution, setAdditionalContribution] = useState<number>(100);
  const [contributionFrequency, setContributionFrequency] = useState<string>("monthly");
  const [futureValue, setFutureValue] = useState<number>(0);
  const [totalContributions, setTotalContributions] = useState<number>(0);
  const [interestEarned, setInterestEarned] = useState<number>(0);

  // Calculate compound interest
  useEffect(() => {
    // Convert interest rate from percentage to decimal
    const rateDecimal = rate / 100;
    
    // Set compounding periods per year
    let periodsPerYear = 1;
    if (compoundFrequency === "monthly") periodsPerYear = 12;
    if (compoundFrequency === "quarterly") periodsPerYear = 4;
    if (compoundFrequency === "daily") periodsPerYear = 365;
    
    // Calculate contributions per year
    let contributionsPerYear = 0;
    if (contributionFrequency === "monthly") contributionsPerYear = 12;
    if (contributionFrequency === "quarterly") contributionsPerYear = 4;
    if (contributionFrequency === "yearly") contributionsPerYear = 1;
    
    // Calculate future value with compound interest
    const n = periodsPerYear * time;
    const i = rateDecimal / periodsPerYear;
    
    // Calculate for lump sum
    const lumpSumFV = principal * Math.pow(1 + i, n);
    
    // Calculate for regular contributions (PMT)
    const contributionsPer = additionalContribution * (contributionsPerYear / periodsPerYear);
    let contributionsFV = 0;
    
    if (i > 0) {
      contributionsFV = contributionsPer * ((Math.pow(1 + i, n) - 1) / i);
    } else {
      contributionsFV = contributionsPer * n;
    }
    
    // Total future value
    const totalFV = lumpSumFV + contributionsFV;
    
    // Total contributions
    const totalContributed = principal + (additionalContribution * contributionsPerYear * time);
    
    setFutureValue(Math.round(totalFV * 100) / 100);
    setTotalContributions(Math.round(totalContributed * 100) / 100);
    setInterestEarned(Math.round((totalFV - totalContributed) * 100) / 100);
  }, [principal, rate, time, compoundFrequency, additionalContribution, contributionFrequency]);

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
    }).format(value);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <Button 
        variant="ghost" 
        className="mb-6 hover:bg-zinc-800" 
        onClick={onBack}
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to Tools
      </Button>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card className="bg-zinc-900 border-zinc-800 shadow-lg">
            <CardHeader>
              <div className="flex items-center mb-2">
                <div className="h-10 w-10 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                  <Calculator className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <CardTitle>Compound Interest Calculator</CardTitle>
                  <CardDescription>See how your investments can grow over time</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Initial Investment */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label htmlFor="principal" className="flex items-center">
                    <Coins className="h-4 w-4 mr-2 text-primary" />
                    Initial Investment
                  </Label>
                  <span className="text-primary font-medium">{formatCurrency(principal)}</span>
                </div>
                <div className="relative">
                  <DollarSign className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="principal"
                    type="number"
                    value={principal}
                    onChange={(e) => setPrincipal(Number(e.target.value))}
                    className="pl-9 bg-zinc-800 border-zinc-700"
                  />
                </div>
                <Slider
                  value={[principal]}
                  min={0}
                  max={100000}
                  step={100}
                  onValueChange={(value) => setPrincipal(value[0])}
                  className="py-4"
                />
              </div>
              
              {/* Annual Interest Rate */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label htmlFor="rate" className="flex items-center">
                    <TrendingUp className="h-4 w-4 mr-2 text-amber-400" />
                    Annual Interest Rate
                  </Label>
                  <span className="text-amber-400 font-medium">{rate}%</span>
                </div>
                <Input
                  id="rate"
                  type="number"
                  value={rate}
                  onChange={(e) => setRate(Number(e.target.value))}
                  className="bg-zinc-800 border-zinc-700"
                />
                <Slider
                  value={[rate]}
                  min={0}
                  max={20}
                  step={0.1}
                  onValueChange={(value) => setRate(value[0])}
                  className="py-4"
                />
              </div>
              
              {/* Time Period */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label htmlFor="time" className="flex items-center">
                    <Calendar className="h-4 w-4 mr-2 text-green-400" />
                    Time Period (Years)
                  </Label>
                  <span className="text-green-400 font-medium">{time} years</span>
                </div>
                <Input
                  id="time"
                  type="number"
                  value={time}
                  onChange={(e) => setTime(Number(e.target.value))}
                  className="bg-zinc-800 border-zinc-700"
                />
                <Slider
                  value={[time]}
                  min={1}
                  max={50}
                  step={1}
                  onValueChange={(value) => setTime(value[0])}
                  className="py-4"
                />
              </div>
              
              {/* Compounding Frequency */}
              <div className="space-y-2">
                <Label htmlFor="compound-frequency" className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2 text-blue-400" />
                  Compounding Frequency
                </Label>
                <Select 
                  value={compoundFrequency} 
                  onValueChange={setCompoundFrequency}
                >
                  <SelectTrigger id="compound-frequency" className="bg-zinc-800 border-zinc-700">
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="yearly">Yearly</SelectItem>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="daily">Daily</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              {/* Regular Contribution */}
              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label htmlFor="contribution" className="flex items-center">
                    <Coins className="h-4 w-4 mr-2 text-purple-400" />
                    Regular Contribution
                  </Label>
                  <span className="text-purple-400 font-medium">{formatCurrency(additionalContribution)}</span>
                </div>
                <div className="relative">
                  <DollarSign className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    id="contribution"
                    type="number"
                    value={additionalContribution}
                    onChange={(e) => setAdditionalContribution(Number(e.target.value))}
                    className="pl-9 bg-zinc-800 border-zinc-700"
                  />
                </div>
                <Slider
                  value={[additionalContribution]}
                  min={0}
                  max={5000}
                  step={50}
                  onValueChange={(value) => setAdditionalContribution(value[0])}
                  className="py-4"
                />
              </div>
              
              {/* Contribution Frequency */}
              <div className="space-y-2">
                <Label htmlFor="contribution-frequency" className="flex items-center">
                  <Calendar className="h-4 w-4 mr-2 text-orange-400" />
                  Contribution Frequency
                </Label>
                <Select 
                  value={contributionFrequency} 
                  onValueChange={setContributionFrequency}
                >
                  <SelectTrigger id="contribution-frequency" className="bg-zinc-800 border-zinc-700">
                    <SelectValue placeholder="Select frequency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                    <SelectItem value="yearly">Yearly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Results */}
        <div>
          <Card className="bg-zinc-900 border-zinc-800 shadow-lg sticky top-6">
            <CardHeader>
              <CardTitle>Results</CardTitle>
              <CardDescription>Your investment growth</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
                <h4 className="text-sm font-medium text-neutral-400 mb-1">Future Value</h4>
                <p className="text-2xl font-bold text-primary">{formatCurrency(futureValue)}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-lg bg-zinc-800 border border-zinc-700">
                  <h4 className="text-sm font-medium text-neutral-400 mb-1">Total Contributions</h4>
                  <p className="text-lg font-bold text-white">{formatCurrency(totalContributions)}</p>
                </div>
                
                <div className="p-4 rounded-lg bg-zinc-800 border border-zinc-700">
                  <h4 className="text-sm font-medium text-neutral-400 mb-1">Interest Earned</h4>
                  <p className="text-lg font-bold text-green-400">{formatCurrency(interestEarned)}</p>
                </div>
              </div>
              
              <div className="h-6 w-full bg-zinc-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-primary to-purple-500" 
                  style={{ width: `${Math.min(interestEarned / futureValue * 100, 100)}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-xs text-neutral-400">
                <div>Principal + Contributions</div>
                <div>Interest Earned</div>
              </div>
            </CardContent>
            <CardFooter>
              <Button className="w-full" variant="outline" onClick={() => {}}>
                Save Results
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
}