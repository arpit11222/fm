import { Card, CardContent } from "@/components/ui/card";
import { getFinanceIcon } from "@/lib/finance-icons";
import { formatDistanceToNow } from "date-fns";
import { motion } from "framer-motion";

interface AchievementBadgeProps {
  name: string;
  iconName: string;
  earnedDate?: Date;
  locked?: boolean;
  isNew?: boolean;
  requirement?: string;
}

export function AchievementBadge({ 
  name, 
  iconName, 
  earnedDate, 
  locked = false, 
  isNew = false,
  requirement
}: AchievementBadgeProps) {
  const Icon = getFinanceIcon(iconName);
  
  // Format earned date as "X days ago" or "today"
  const formattedDate = earnedDate 
    ? formatDistanceToNow(earnedDate, { addSuffix: true })
    : "";
  
  const badge = (
    <Card className={`bg-white rounded-xl shadow-md p-4 flex flex-col items-center justify-center transition-transform hover:translate-y-[-5px] ${locked ? "opacity-60" : ""}`}>
      <div className={`w-16 h-16 rounded-full flex items-center justify-center ${locked ? "bg-neutral-200" : iconName === "fire-element" ? "bg-primary bg-opacity-20" : iconName === "money-box" ? "bg-amber-100" : "bg-blue-100"}`}>
        {locked ? (
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-neutral-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
            <path d="M7 11V7a5 5 0 0 1 10 0v4" />
          </svg>
        ) : (
          <Icon className={`w-8 h-8 ${iconName === "fire-element" ? "text-primary" : iconName === "money-box" ? "text-amber-500" : "text-blue-500"}`} />
        )}
      </div>
      <h3 className="mt-3 font-medium text-sm text-center text-neutral-800">{name}</h3>
      <p className="text-xs text-neutral-500 mt-1">
        {locked ? requirement : `Earned ${formattedDate}`}
      </p>
    </Card>
  );
  
  if (isNew) {
    return (
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ 
          type: "spring", 
          stiffness: 260, 
          damping: 20,
          duration: 0.5
        }}
      >
        {badge}
      </motion.div>
    );
  }
  
  return badge;
}
