import { Link, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { AvatarImage } from "@/components/ui/avatar-image";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { 
  Menu, 
  BookOpen, 
  Trophy, 
  ChevronDown, 
  BarChart3, 
  Lightbulb, 
  HelpCircle, 
  BookMarked,
  LogOut
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import useMobile from "@/hooks/use-mobile";

export default function Header() {
  const [location] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const isMobile = useMobile();

  const navItems = [
    { label: "Home", href: "/", icon: <BookMarked className="h-4 w-4 mr-1" />, requireAuth: false },
    { label: "Courses", href: "/courses", icon: <BookOpen className="h-4 w-4 mr-1" />, requireAuth: true },
    { label: "Practice", href: "/practice", icon: <Lightbulb className="h-4 w-4 mr-1" />, requireAuth: true },
    { label: "Analytics", href: "/analytics", icon: <BarChart3 className="h-4 w-4 mr-1" />, requireAuth: true },
    { label: "Achievements", href: "/achievements", icon: <Trophy className="h-4 w-4 mr-1" />, requireAuth: true },
  ];

  const resourceItems = [
    { label: "Guides", href: "/resources/guides" },
    { label: "Finance Tools", href: "/resources/tools" },
    { label: "Glossary", href: "/resources/glossary" },
    { label: "FAQ", href: "/resources/faq" },
  ];

  const filteredNavItems = navItems.filter(
    item => !item.requireAuth || isAuthenticated
  );

  const renderNavItems = () => (
    <>
      {filteredNavItems.map((item) => (
        <Link 
          key={item.href} 
          href={item.href}
          className={`font-medium px-3 py-2 rounded-md text-sm flex items-center ${
            location === item.href 
              ? "text-primary bg-primary/10" 
              : "text-neutral-200 hover:text-primary hover:bg-primary/5"
          }`}
        >
          {item.icon}
          {item.label}
        </Link>
      ))}
      
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <a className="font-medium px-3 py-2 rounded-md text-sm flex items-center text-neutral-200 hover:text-primary cursor-pointer">
            <HelpCircle className="h-4 w-4 mr-1" />
            Resources
            <ChevronDown className="h-4 w-4 ml-1" />
          </a>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-40">
          {resourceItems.map((item) => (
            <Link key={item.href} href={item.href}>
              <DropdownMenuItem className="cursor-pointer">
                {item.label}
              </DropdownMenuItem>
            </Link>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </>
  );

  return (
    <header className="bg-black shadow-lg border-b border-zinc-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <Link 
              href="/"
              className="flex-shrink-0 font-bold text-2xl font-space"
            >
              <span className="text-primary">Fin</span>
              <span className="text-amber-400">Mate</span>
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-2 items-center">
            {renderNavItems()}
          </nav>
          
          {/* User Menu or Auth Buttons */}
          <div className="flex items-center space-x-4">
            {isAuthenticated && user ? (
              <>
                <div className="hidden md:flex items-center px-3 py-1 bg-zinc-900 rounded-full border border-zinc-800">
                  <span className="text-amber-500 mr-2">🔥</span>
                  <span className="font-medium text-white">{user.streak}</span>
                  <span className="ml-1 text-neutral-400 text-sm">streak</span>
                </div>
                
                <div className="hidden md:flex items-center px-3 py-1 bg-zinc-900 rounded-full border border-zinc-800">
                  <span className="text-amber-500 mr-2">💎</span>
                  <span className="font-medium text-white">{user.experience}</span>
                  <span className="ml-1 text-neutral-400 text-sm">XP</span>
                </div>
                
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <div className="relative cursor-pointer">
                      <AvatarImage name={user.displayName} />
                    </div>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <div className="px-4 py-2 border-b border-gray-200">
                      <p className="font-medium">{user.displayName}</p>
                      <p className="text-sm text-gray-500">{user.email}</p>
                    </div>
                    <Link href="/profile">
                      <DropdownMenuItem className="cursor-pointer">
                        Profile
                      </DropdownMenuItem>
                    </Link>
                    <Link href="/settings">
                      <DropdownMenuItem className="cursor-pointer">
                        Settings
                      </DropdownMenuItem>
                    </Link>
                    <DropdownMenuItem className="cursor-pointer text-red-500" onClick={logout}>
                      <LogOut className="h-4 w-4 mr-2" />
                      Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <>
                {!isMobile && (
                  <>
                    <Link href="/auth">
                      <Button variant="outline" size="sm" className="text-neutral-200 border-gray-700 hover:bg-gray-800">
                        Sign In
                      </Button>
                    </Link>
                    <Link href="/auth?tab=register">
                      <Button size="sm">Sign Up</Button>
                    </Link>
                  </>
                )}
              </>
            )}
            
            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-neutral-200">
                    <Menu className="h-5 w-5" />
                    <span className="sr-only">Toggle menu</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="right" className="bg-black text-neutral-200 border-l border-zinc-800">
                  <div className="flex flex-col gap-4 mt-6">
                    {filteredNavItems.map((item) => (
                      <Link 
                        key={item.href} 
                        href={item.href}
                        className={`font-medium px-3 py-2 rounded-md text-sm flex items-center ${
                          location === item.href 
                            ? "text-primary bg-primary/10" 
                            : "text-neutral-200 hover:text-primary"
                        }`}
                      >
                        {item.icon}
                        {item.label}
                      </Link>
                    ))}
                    
                    <div className="px-3 py-2 text-sm font-medium text-neutral-200">Resources</div>
                    {resourceItems.map((item) => (
                      <Link 
                        key={item.href} 
                        href={item.href}
                        className="px-6 py-2 text-sm text-neutral-300 hover:text-primary"
                      >
                        {item.label}
                      </Link>
                    ))}
                    
                    {isAuthenticated ? (
                      <>
                        <div className="border-t border-zinc-800 mt-2 pt-4"></div>
                        <div className="flex items-center gap-2 px-3 py-2">
                          <AvatarImage name={user?.displayName || "User"} size="sm" />
                          <span>{user?.displayName}</span>
                        </div>
                        <Button variant="destructive" className="mt-2" onClick={logout}>
                          <LogOut className="h-4 w-4 mr-2" />
                          Sign Out
                        </Button>
                      </>
                    ) : (
                      <>
                        <div className="border-t border-zinc-800 mt-2 pt-4"></div>
                        <Link href="/auth">
                          <Button variant="outline" className="w-full text-neutral-200 border-zinc-800 hover:bg-zinc-900">
                            Sign In
                          </Button>
                        </Link>
                        <Link href="/auth?tab=register">
                          <Button className="w-full">Sign Up</Button>
                        </Link>
                      </>
                    )}
                  </div>
                </SheetContent>
              </Sheet>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
