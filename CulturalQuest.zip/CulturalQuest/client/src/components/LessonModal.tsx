import { useState } from "react";
import { Button } from "@/components/ui/button";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription 
} from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Lesson } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Lightbulb } from "lucide-react";

interface LessonModalProps {
  lesson: Lesson;
  isOpen: boolean;
  onClose: () => void;
  currentStep: number;
  totalSteps: number;
}

export function LessonModal({ 
  lesson, 
  isOpen, 
  onClose, 
  currentStep, 
  totalSteps 
}: LessonModalProps) {
  const [showHint, setShowHint] = useState(false);
  const [answer, setAnswer] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();
  
  const progressPercentage = (currentStep / totalSteps) * 100;
  
  const content = lesson?.content;
  const question = content?.questions?.[0];
  
  const { mutate, isPending } = useMutation({
    mutationFn: async (data: { completed: boolean, progress: number }) => {
      return apiRequest('POST', '/api/progress', {
        lessonId: lesson.id,
        courseId: lesson.courseId,
        ...data
      });
    },
    onSuccess: () => {
      toast({
        title: "Progress saved!",
        description: "You've earned " + lesson.xpReward + " XP!",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/progress'] });
      queryClient.invalidateQueries({ queryKey: ['/api/auth/me'] });
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Error saving progress",
        description: String(error),
        variant: "destructive",
      });
    }
  });
  
  const handleNext = () => {
    // In a real app, this would check the answer and update progress
    mutate({ completed: true, progress: 100 });
  };
  
  const toggleHint = () => {
    setShowHint(!showHint);
  };
  
  if (!lesson) return null;
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl w-full p-6">
        <DialogHeader>
          <DialogTitle className="text-xl">Lesson: {lesson.title}</DialogTitle>
          <DialogDescription>
            {lesson.description}
          </DialogDescription>
        </DialogHeader>
        
        {/* Progress Bar */}
        <div className="mt-4">
          <Progress value={progressPercentage} className="h-2.5" />
          <div className="flex justify-between text-sm text-neutral-500 mt-1">
            <span>Step {currentStep} of {totalSteps}</span>
            <span>{lesson.xpReward} XP</span>
          </div>
        </div>
        
        {/* Lesson Content */}
        <div className="mt-6">
          <h3 className="font-medium text-neutral-800">{content?.text?.split('.')[0]}</h3>
          <p className="mt-2 text-neutral-600">{content?.text}</p>
          
          {question && (
            <div className="mt-4 p-4 bg-neutral-100 rounded-xl">
              <p className="font-medium text-neutral-800">{question.question}</p>
              
              {question.type === "multiple-choice" && (
                <div className="mt-2 space-y-2">
                  {question.options.map((option, index) => (
                    <div 
                      key={index}
                      className={`p-3 rounded-md border cursor-pointer transition-colors ${
                        index === question.correctAnswerIndex 
                          ? "border-green-500 bg-green-50" 
                          : "border-neutral-300 hover:border-primary"
                      }`}
                      onClick={() => console.log(`Selected option ${index + 1}`)}
                    >
                      {option}
                    </div>
                  ))}
                </div>
              )}
              
              {question.type === "text-input" && (
                <div className="mt-4">
                  <label className="block text-sm font-medium text-neutral-700">Your answer:</label>
                  <Input 
                    className="mt-1"
                    value={answer}
                    onChange={(e) => setAnswer(e.target.value)}
                    placeholder="Type your answer here..."
                  />
                </div>
              )}
              
              <div className="mt-4">
                <Button 
                  variant="outline" 
                  onClick={toggleHint}
                  className="text-neutral-700"
                >
                  <Lightbulb className="mr-2 h-4 w-4" />
                  Get Hint
                </Button>
                {showHint && (
                  <div className="mt-2 p-3 bg-amber-50 rounded-md text-sm text-neutral-700">
                    <p><strong>Hint:</strong> {question.explanation}</p>
                  </div>
                )}
              </div>
            </div>
          )}
          
          <div className="mt-6 flex justify-between">
            <Button variant="outline">
              Previous
            </Button>
            <Button onClick={handleNext} disabled={isPending}>
              {isPending ? "Saving..." : "Continue"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
