import React, { createContext, useContext, useState, useEffect } from "react";

// Define the User type
export type User = {
  id: number;
  username: string;
  displayName: string;
  email: string;
  level: number;
  experience: number;
  streak: number;
  lastLogin: string;
  createdAt: string;
};

// Define the Auth Context type
export type AuthContextType = {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (username: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};

// Create the context with a default value
const AuthContext = createContext<AuthContextType>({
  user: null,
  isAuthenticated: false,
  isLoading: false,
  login: async () => {
    throw new Error('AuthContext not initialized');
  },
  logout: async () => {
    throw new Error('AuthContext not initialized');
  },
});

// Export the provider component
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Check auth status on mount
  useEffect(() => {
    checkAuthStatus();
  }, []);

  // Login function
  const login = async (username: string, password: string) => {
    try {
      console.log("Attempting login with:", { username });
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
        credentials: "include",
      });

      if (!response.ok) {
        let errorMessage = "Login failed. Please check your credentials.";
        try {
          const errorData = await response.json();
          errorMessage = errorData.message || errorMessage;
        } catch (e) {
          // If response is not valid JSON, use default error message
        }
        console.error("Login response error:", errorMessage);
        throw new Error(errorMessage);
      }
      
      try {
        const userData = await response.json();
        console.log("Login successful:", userData);
        setUser(userData);
        
        // Force a check with the server to confirm our login state
        setTimeout(() => {
          checkAuthStatus();
        }, 100);
        
        return userData;
      } catch (parseError) {
        console.error("Error parsing user data:", parseError);
        throw new Error("Error processing login response");
      }
    } catch (error: any) {
      console.error("Login error:", error);
      throw error;
    }
  };

  // Function to check authentication status
  async function checkAuthStatus() {
    try {
      console.log("Checking auth status...");
      const response = await fetch("/api/auth/me", {
        credentials: "include",
      });

      if (response.ok) {
        const userData = await response.json();
        console.log("User authenticated:", userData);
        setUser(userData);
      } else {
        console.log("User not authenticated");
        setUser(null);
      }
    } catch (error) {
      console.error("Error fetching auth status:", error);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  }

  // Logout function
  const logout = async () => {
    try {
      const response = await fetch("/api/auth/logout", {
        method: "POST",
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Logout request failed");
      }
      
      setUser(null);
      console.log("Logged out successfully");
    } catch (error: any) {
      console.error("Logout failed:", error.message);
    }
  };

  // Context value
  const contextValue = {
    user,
    isAuthenticated: !!user,
    isLoading,
    login,
    logout,
  };

  return (
    <AuthContext.Provider value={contextValue}>
      {children}
    </AuthContext.Provider>
  );
}

// Export the hook to use this context
export function useAuth() {
  const context = useContext(AuthContext);
  return context;
}
