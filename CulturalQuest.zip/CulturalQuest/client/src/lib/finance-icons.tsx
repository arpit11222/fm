import { 
  Book, 
  ChartPie, 
  CreditCard, 
  DollarSign,
  PiggyBank, 
  LineChart, 
  Building, 
  Flag, 
  BarChart3,
  Wallet,
  Briefcase,
  Shield,
  Heart,
  Home,
  Calculator,
  TrendingUp,
  BadgePercent,
  Landmark,
  ClipboardList,
  Award,
  Zap,
  HelpCircle,
  Icon
} from "lucide-react";
import { FaHandHoldingUsd, FaMoneyBillWave, FaChartBar, FaMoneyCheck, FaCoins, FaHandshake } from "react-icons/fa";

// Map icon names to components
const iconMap: Record<string, any> = {
  // Lucide icons
  "book": Book,
  "chart-pie": ChartPie,
  "credit-card": CreditCard,
  "dollar-sign": DollarSign,
  "piggy-bank": PiggyBank,
  "chart-line": LineChart,
  "building": Building,
  "flag": Flag,
  "bar-chart": BarChart3,
  "wallet": Wallet,
  "briefcase": Briefcase,
  "shield": Shield,
  "heart": Heart,
  "home": Home,
  "calculator": Calculator,
  "trending-up": TrendingUp,
  "badge-percent": BadgePercent,
  "landmark": Landmark,
  "clipboard-list": ClipboardList,
  "award": Award,
  "zap": Zap,
  
  // Custom or achievement icons 
  "money-box": PiggyBank,
  "fire-element": Zap,
  "quiz": ClipboardList,
  "trophy": Award,
  
  // React Icons fallbacks
  "hand-holding-usd": FaHandHoldingUsd,
  "money-bill-wave": FaMoneyBillWave,
  "chart-bar": FaChartBar,
  "money-check": FaMoneyCheck,
  "coins": FaCoins,
  "handshake": FaHandshake
};

/**
 * Gets the appropriate finance icon component
 * @param iconName Name of the icon to retrieve
 * @returns The icon component or a fallback if not found
 */
export function getFinanceIcon(iconName: string): Icon {
  // Return the requested icon or fallback to a question mark icon
  return iconMap[iconName] || HelpCircle;
}
