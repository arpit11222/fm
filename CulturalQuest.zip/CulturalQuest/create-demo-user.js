import { execSync } from 'child_process';
import { hashSync } from 'bcrypt';

// Demo user credentials
const demoUser = {
  username: "demo",
  password: "password123",
  email: "demo@finmate.com",
  displayName: "Demo User"
};

// Hash the password
const hashedPassword = hashSync(demoUser.password, 10);

// SQL query to insert the demo user
const insertQuery = `
INSERT INTO users (username, password, email, display_name, level, experience, streak, last_login, created_at) 
VALUES (
  '${demoUser.username}', 
  '${hashedPassword}', 
  '${demoUser.email}', 
  '${demoUser.displayName}', 
  5, 
  250, 
  7, 
  NOW(), 
  NOW()
) ON CONFLICT (username) DO NOTHING;
`;

// Execute the query
try {
  execSync(`psql ${process.env.DATABASE_URL} -c "${insertQuery}"`, {
    stdio: 'inherit'
  });
  console.log('Demo user created successfully!');
  console.log('Username:', demoUser.username);
  console.log('Password:', demoUser.password);
} catch (error) {
  console.error('Error creating demo user:', error);
}