import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import memoryStore from "memorystore";
import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  insertUserProgressSchema, 
  insertUserAchievementSchema 
} from "@shared/schema";
import { compareSync, hashSync } from "bcrypt";

// Initialize memory store for sessions
const MemoryStore = memoryStore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize storage with sample data
  await storage.initializeData();

  // Session configuration
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "fin-learn-secret",
      resave: false,
      saveUninitialized: false,
      store: new MemoryStore({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      cookie: {
        secure: process.env.NODE_ENV === "production",
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      },
    })
  );

  // Initialize passport
  app.use(passport.initialize());
  app.use(passport.session());

  // Passport local strategy for authentication
  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user) {
          return done(null, false, { message: "Invalid username or password" });
        }

        // Check if password matches using bcrypt
        if (!compareSync(password, user.password)) {
          return done(null, false, { message: "Invalid username or password" });
        }

        return done(null, user);
      } catch (error) {
        return done(error);
      }
    })
  );

  // Serialize and deserialize user
  passport.serializeUser((user: any, done) => {
    done(null, user.id);
  });

  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Authentication middleware
  const requireAuth = (req: Request, res: Response, next: any) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  // == Auth Routes ==
  // Register route
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already taken" });
      }
      
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ message: "Email already in use" });
      }
      
      // Hash the password before saving
      const hashedPassword = hashSync(userData.password, 10);
      
      // Create the user with hashed password
      const newUser = await storage.createUser({
        ...userData,
        password: hashedPassword
      });
      
      // Remove password from response
      const { password, ...userWithoutPassword } = newUser;
      
      res.status(201).json(userWithoutPassword);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  // Special Demo Login route
  app.post("/api/auth/demo-login", async (req, res) => {
    try {
      console.log("Demo login attempt...");
      const demoUser = await storage.getUserByUsername("demo");
      
      if (!demoUser) {
        return res.status(404).json({ message: "Demo user not found" });
      }
      
      // Update last login and streak for demo user
      await storage.updateUserLastLogin(demoUser.id);
      const updatedUser = await storage.updateUserStreak(demoUser.id, demoUser.streak + 1);
      
      // Log in the demo user without password check
      req.login(updatedUser, (err) => {
        if (err) {
          console.error("Demo login error:", err);
          return res.status(500).json({ message: "Error logging in demo user" });
        }
        
        // Remove password from response
        const { password, ...userWithoutPassword } = updatedUser;
        console.log("Demo login successful");
        return res.json(userWithoutPassword);
      });
    } catch (error) {
      console.error("Demo login error:", error);
      res.status(500).json({ message: "Error logging in demo user" });
    }
  });

  // Regular Login route 
  app.post("/api/auth/login", (req, res, next) => {
    console.log("Regular login attempt...");
    
    // Special case for demo user
    if (req.body.username === "demo" && req.body.password === "password123") {
      console.log("Redirecting to demo login...");
      return res.redirect(307, "/api/auth/demo-login");
    }
    
    passport.authenticate("local", (err: any, user: any, info: any) => {
      if (err) {
        return next(err);
      }
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid username or password" });
      }
      
      req.logIn(user, async (err) => {
        if (err) {
          return next(err);
        }
        
        // Update last login and check streak
        await storage.updateUserLastLogin(user.id);
        
        // Calculate streak (in a real app, would compare dates)
        const updatedUser = await storage.updateUserStreak(user.id, user.streak + 1);
        
        // Remove password from response
        const { password, ...userWithoutPassword } = updatedUser;
        
        return res.json(userWithoutPassword);
      });
    })(req, res, next);
  });

  // Logout route
  app.post("/api/auth/logout", (req, res) => {
    req.logout((err) => {
      if (err) {
        return res.status(500).json({ message: "Error logging out" });
      }
      res.json({ message: "Logged out successfully" });
    });
  });

  // Get current user route
  app.get("/api/auth/me", requireAuth, (req, res) => {
    const { password, ...userWithoutPassword } = req.user as any;
    res.json(userWithoutPassword);
  });

  // == Course Routes ==
  // Get all courses
  app.get("/api/courses", async (req, res) => {
    try {
      const courses = await storage.getAllCourses();
      res.json(courses);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get courses by category
  app.get("/api/courses/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const courses = await storage.getCoursesByCategory(category);
      res.json(courses);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get course by id
  app.get("/api/courses/:id", async (req, res) => {
    try {
      const courseId = parseInt(req.params.id);
      const course = await storage.getCourse(courseId);
      
      if (!course) {
        return res.status(404).json({ message: "Course not found" });
      }
      
      res.json(course);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // == Lesson Routes ==
  // Get lessons by course
  app.get("/api/courses/:courseId/lessons", async (req, res) => {
    try {
      const courseId = parseInt(req.params.courseId);
      const lessons = await storage.getLessonsByCourse(courseId);
      res.json(lessons);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get lesson by id
  app.get("/api/lessons/:id", async (req, res) => {
    try {
      const lessonId = parseInt(req.params.id);
      const lesson = await storage.getLesson(lessonId);
      
      if (!lesson) {
        return res.status(404).json({ message: "Lesson not found" });
      }
      
      res.json(lesson);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // == User Progress Routes ==
  // Get user progress
  app.get("/api/progress", requireAuth, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const progress = await storage.getUserProgress(userId);
      res.json(progress);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get user course progress
  app.get("/api/progress/course/:courseId", requireAuth, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const courseId = parseInt(req.params.courseId);
      const progress = await storage.getUserCourseProgress(userId, courseId);
      
      if (!progress) {
        return res.json({ completed: false, progress: 0 });
      }
      
      res.json(progress);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Update user progress
  app.post("/api/progress", requireAuth, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const progressData = insertUserProgressSchema.parse({
        ...req.body,
        userId
      });
      
      const progress = await storage.createOrUpdateUserProgress(progressData);
      
      // If lesson completed, award XP
      if (progress.completed && progress.lessonId) {
        const lesson = await storage.getLesson(progress.lessonId);
        if (lesson) {
          await storage.updateUserExperience(userId, lesson.xpReward);
        }
      }
      
      res.json(progress);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // == Achievement Routes ==
  // Get all achievements
  app.get("/api/achievements", async (req, res) => {
    try {
      const achievements = await storage.getAllAchievements();
      res.json(achievements);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get user achievements
  app.get("/api/achievements/user", requireAuth, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const userAchievements = await storage.getUserAchievements(userId);
      
      // Join with achievement details
      const achievements = await Promise.all(
        userAchievements.map(async (userAchievement) => {
          const achievement = await storage.getAchievement(userAchievement.achievementId);
          return {
            ...userAchievement,
            achievement
          };
        })
      );
      
      res.json(achievements);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Award achievement to user
  app.post("/api/achievements/award", requireAuth, async (req, res) => {
    try {
      const userId = (req.user as any).id;
      const { achievementId } = insertUserAchievementSchema.parse({
        ...req.body,
        userId
      });
      
      const achievement = await storage.getAchievement(achievementId);
      if (!achievement) {
        return res.status(404).json({ message: "Achievement not found" });
      }
      
      const userAchievement = await storage.createUserAchievement({
        userId,
        achievementId
      });
      
      res.json({
        ...userAchievement,
        achievement
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
