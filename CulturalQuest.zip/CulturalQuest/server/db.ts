import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import * as schema from "@shared/schema";

// Create postgres connection
const queryClient = postgres(process.env.DATABASE_URL!);

// Setup drizzle ORM
export const db = drizzle(queryClient, { schema });