import {
  users, type User, type InsertUser,
  courses, type Course, type InsertCourse,
  lessons, type Lesson, type InsertLesson,
  userProgress, type UserProgress, type InsertUserProgress,
  achievements, type Achievement, type InsertAchievement,
  userAchievements, type UserAchievement, type InsertUserAchievement
} from "@shared/schema";
import { hashSync, compareSync } from "bcrypt";
import { db } from "./db";
import { eq, and, isNull } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserExperience(userId: number, xpAmount: number): Promise<User>;
  updateUserStreak(userId: number, streak: number): Promise<User>;
  updateUserLastLogin(userId: number): Promise<User>;

  // Course operations
  getAllCourses(): Promise<Course[]>;
  getCourse(id: number): Promise<Course | undefined>;
  getCoursesByCategory(category: string): Promise<Course[]>;
  createCourse(course: InsertCourse): Promise<Course>;

  // Lesson operations
  getLessonsByCourse(courseId: number): Promise<Lesson[]>;
  getLesson(id: number): Promise<Lesson | undefined>;
  createLesson(lesson: InsertLesson): Promise<Lesson>;

  // User Progress operations
  getUserProgress(userId: number): Promise<UserProgress[]>;
  getUserCourseProgress(userId: number, courseId: number): Promise<UserProgress | undefined>;
  getUserLessonProgress(userId: number, lessonId: number): Promise<UserProgress | undefined>;
  createOrUpdateUserProgress(progress: InsertUserProgress): Promise<UserProgress>;

  // Achievement operations
  getAllAchievements(): Promise<Achievement[]>;
  getAchievement(id: number): Promise<Achievement | undefined>;
  createAchievement(achievement: InsertAchievement): Promise<Achievement>;

  // User Achievement operations
  getUserAchievements(userId: number): Promise<UserAchievement[]>;
  createUserAchievement(userAchievement: InsertUserAchievement): Promise<UserAchievement>;
  
  // Initialization
  initializeData(): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserExperience(userId: number, xpAmount: number): Promise<User> {
    // Get the current user
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    const newXp = user.experience + xpAmount;
    // Simple leveling formula: level = 1 + (xp / 100)
    const newLevel = Math.floor(1 + (newXp / 100));
    
    // Update user
    const [updatedUser] = await db
      .update(users)
      .set({ experience: newXp, level: newLevel })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  async updateUserStreak(userId: number, streak: number): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({ streak })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  async updateUserLastLogin(userId: number): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({ lastLogin: new Date() })
      .where(eq(users.id, userId))
      .returning();
    
    return updatedUser;
  }

  async getAllCourses(): Promise<Course[]> {
    return db.select().from(courses);
  }

  async getCourse(id: number): Promise<Course | undefined> {
    const [course] = await db.select().from(courses).where(eq(courses.id, id));
    return course;
  }

  async getCoursesByCategory(category: string): Promise<Course[]> {
    return db.select().from(courses).where(eq(courses.category, category));
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const [course] = await db.insert(courses).values(insertCourse).returning();
    return course;
  }

  async getLessonsByCourse(courseId: number): Promise<Lesson[]> {
    return db
      .select()
      .from(lessons)
      .where(eq(lessons.courseId, courseId))
      .orderBy(lessons.order);
  }

  async getLesson(id: number): Promise<Lesson | undefined> {
    const [lesson] = await db.select().from(lessons).where(eq(lessons.id, id));
    return lesson;
  }

  async createLesson(insertLesson: InsertLesson): Promise<Lesson> {
    const [lesson] = await db.insert(lessons).values(insertLesson).returning();
    return lesson;
  }

  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return db.select().from(userProgress).where(eq(userProgress.userId, userId));
  }

  async getUserCourseProgress(userId: number, courseId: number): Promise<UserProgress | undefined> {
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(
        and(
          eq(userProgress.userId, userId),
          eq(userProgress.courseId, courseId),
          isNull(userProgress.lessonId)
        )
      );
    return progress;
  }

  async getUserLessonProgress(userId: number, lessonId: number): Promise<UserProgress | undefined> {
    const [progress] = await db
      .select()
      .from(userProgress)
      .where(
        and(
          eq(userProgress.userId, userId),
          eq(userProgress.lessonId, lessonId)
        )
      );
    return progress;
  }

  async createOrUpdateUserProgress(insertProgress: InsertUserProgress): Promise<UserProgress> {
    // Check if progress already exists
    const existingProgress = insertProgress.lessonId 
      ? await this.getUserLessonProgress(insertProgress.userId, insertProgress.lessonId)
      : await this.getUserCourseProgress(insertProgress.userId, insertProgress.courseId);
    
    if (existingProgress) {
      // Update existing progress
      const [updatedProgress] = await db
        .update(userProgress)
        .set({ 
          ...insertProgress, 
          updatedAt: new Date() 
        })
        .where(eq(userProgress.id, existingProgress.id))
        .returning();
      return updatedProgress;
    } else {
      // Create new progress
      const [newProgress] = await db
        .insert(userProgress)
        .values({
          ...insertProgress,
          completed: insertProgress.completed || false,
          progress: insertProgress.progress || 0,
          updatedAt: new Date()
        })
        .returning();
      return newProgress;
    }
  }

  async getAllAchievements(): Promise<Achievement[]> {
    return db.select().from(achievements);
  }

  async getAchievement(id: number): Promise<Achievement | undefined> {
    const [achievement] = await db.select().from(achievements).where(eq(achievements.id, id));
    return achievement;
  }

  async createAchievement(insertAchievement: InsertAchievement): Promise<Achievement> {
    const [achievement] = await db.insert(achievements).values(insertAchievement).returning();
    return achievement;
  }

  async getUserAchievements(userId: number): Promise<UserAchievement[]> {
    return db
      .select()
      .from(userAchievements)
      .where(eq(userAchievements.userId, userId));
  }

  async createUserAchievement(insertUserAchievement: InsertUserAchievement): Promise<UserAchievement> {
    // Check if it already exists
    const [existing] = await db
      .select()
      .from(userAchievements)
      .where(
        and(
          eq(userAchievements.userId, insertUserAchievement.userId),
          eq(userAchievements.achievementId, insertUserAchievement.achievementId)
        )
      );
    
    if (existing) {
      return existing;
    }
    
    // Create new user achievement
    const [userAchievement] = await db
      .insert(userAchievements)
      .values({
        ...insertUserAchievement,
        earnedAt: new Date()
      })
      .returning();
    
    return userAchievement;
  }

  async initializeData(): Promise<void> {
    // Create demo user for easy login
    const demoUser: InsertUser = {
      username: "demo",
      email: "demo@example.com", 
      password: "password123",
      displayName: "Demo User"
    };
    
    // Only create if demo user doesn't exist
    const existingDemo = await this.getUserByUsername("demo");
    if (!existingDemo) {
      // Hash the password
      const hashedPassword = hashSync(demoUser.password, 10);
      await this.createUser({
        ...demoUser,
        password: hashedPassword
      });
    }
    
    // Create sample achievements
    const achievementData: InsertAchievement[] = [
      {
        name: "Budgeting Master",
        description: "Complete all budgeting lessons",
        iconName: "money-box",
        requirement: "complete_course",
        requirementValue: 1
      },
      {
        name: "7 Day Streak",
        description: "Log in for 7 consecutive days",
        iconName: "fire-element",
        requirement: "streak",
        requirementValue: 7
      },
      {
        name: "Quiz Whiz",
        description: "Score 100% on 5 quizzes",
        iconName: "quiz",
        requirement: "perfect_quiz",
        requirementValue: 5
      },
      {
        name: "Budget Champion",
        description: "Complete 5 budget lessons",
        iconName: "trophy",
        requirement: "complete_lessons",
        requirementValue: 5
      }
    ];

    for (const achievement of achievementData) {
      // Skip if already exists
      const existingAchievement = await db
        .select()
        .from(achievements)
        .where(eq(achievements.name, achievement.name));
      
      if (existingAchievement.length === 0) {
        await this.createAchievement(achievement);
      }
    }

    // Create sample courses
    const categories = ["Personal Finance", "Investing", "Banking", "Insurance", "Retirement Planning", "Tax Strategies"];
    
    const courseData: InsertCourse[] = [
      {
        name: "Financial Basics",
        description: "Learn the fundamentals of personal finance",
        category: "Personal Finance",
        difficulty: "Beginner",
        duration: "2-3 hours",
        xpReward: 50,
        iconName: "book",
        prerequisiteIds: [],
        order: 1
      },
      {
        name: "Budgeting 101",
        description: "Creating and maintaining a personal budget",
        category: "Personal Finance",
        difficulty: "Beginner",
        duration: "3-4 hours",
        xpReward: 75,
        iconName: "chart-pie",
        prerequisiteIds: [1],
        order: 2
      },
      {
        name: "Debt Management",
        description: "Strategies for managing and reducing debt",
        category: "Personal Finance",
        difficulty: "Intermediate",
        duration: "4-5 hours",
        xpReward: 100,
        iconName: "credit-card",
        prerequisiteIds: [1],
        order: 3
      },
      {
        name: "Investing Basics",
        description: "Introduction to investing concepts",
        category: "Investing",
        difficulty: "Beginner",
        duration: "3-4 hours",
        xpReward: 75,
        iconName: "chart-line",
        prerequisiteIds: [1],
        order: 4
      },
      {
        name: "Stock Market",
        description: "How the stock market works",
        category: "Investing",
        difficulty: "Intermediate",
        duration: "5-6 hours",
        xpReward: 125,
        iconName: "chart-line",
        prerequisiteIds: [4],
        order: 5
      },
      {
        name: "Saving Strategies",
        description: "Effective ways to save money",
        category: "Personal Finance",
        difficulty: "Beginner",
        duration: "2-3 hours",
        xpReward: 50,
        iconName: "piggy-bank",
        prerequisiteIds: [2],
        order: 6
      },
      {
        name: "Credit Score",
        description: "Understanding and improving your credit score",
        category: "Banking",
        difficulty: "Intermediate",
        duration: "3-4 hours",
        xpReward: 75,
        iconName: "credit-card",
        prerequisiteIds: [3],
        order: 7
      },
      {
        name: "Financial Freedom",
        description: "Strategies for achieving financial independence",
        category: "Personal Finance",
        difficulty: "Advanced",
        duration: "6-8 hours",
        xpReward: 150,
        iconName: "flag",
        prerequisiteIds: [2, 4, 7],
        order: 8
      }
    ];

    for (const course of courseData) {
      // Skip if already exists
      const existingCourse = await db
        .select()
        .from(courses)
        .where(eq(courses.name, course.name));
      
      if (existingCourse.length === 0) {
        await this.createCourse(course);
      }
    }

    // Create sample lessons for Budgeting 101
    const budgetingCourse = await db
      .select()
      .from(courses)
      .where(eq(courses.name, "Budgeting 101"));
    
    if (budgetingCourse.length > 0) {
      const courseId = budgetingCourse[0].id;
      const existingLessons = await this.getLessonsByCourse(courseId);
      
      // Only add lessons if none exist
      if (existingLessons.length === 0) {
        const budgetingLessons: InsertLesson[] = [
          {
            courseId,
            title: "Introduction to Budgeting",
            description: "Learn why budgeting is important",
            content: {
              text: "Budgeting is the process of creating a plan to spend your money.",
              questions: [
                {
                  type: "multiple-choice",
                  question: "What is the primary purpose of budgeting?",
                  options: [
                    "To restrict your spending", 
                    "To create a spending plan", 
                    "To make you feel guilty", 
                    "To increase your debt"
                  ],
                  correctAnswerIndex: 1,
                  explanation: "Budgeting is about planning, not restricting."
                }
              ]
            },
            order: 1,
            xpReward: 10
          },
          {
            courseId,
            title: "Creating a Monthly Budget",
            description: "Steps to create your first budget",
            content: {
              text: "Follow these steps to create a monthly budget: list income sources, track expenses, categorize spending.",
              questions: [
                {
                  type: "multiple-choice",
                  question: "Which of the following should you do first when creating a budget?",
                  options: [
                    "Cut all expenses",
                    "Calculate your monthly income",
                    "Apply for a loan",
                    "Set financial goals"
                  ],
                  correctAnswerIndex: 1,
                  explanation: "You need to know your income before planning expenses."
                }
              ]
            },
            order: 2,
            xpReward: 15
          },
          {
            courseId,
            title: "Tracking Expenses",
            description: "Methods for tracking your spending",
            content: {
              text: "Track your expenses using apps, spreadsheets, or pen and paper.",
              questions: [
                {
                  type: "multiple-choice",
                  question: "What is a benefit of tracking expenses?",
                  options: [
                    "It increases your spending",
                    "It helps identify wasteful spending",
                    "It reduces your income",
                    "It increases your debt"
                  ],
                  correctAnswerIndex: 1,
                  explanation: "Tracking helps you see where your money is going."
                }
              ]
            },
            order: 3,
            xpReward: 15
          },
          {
            courseId,
            title: "Setting Financial Goals",
            description: "How to set achievable financial goals",
            content: {
              text: "Learn to set SMART financial goals: Specific, Measurable, Achievable, Relevant, Time-bound.",
              questions: [
                {
                  type: "multiple-choice",
                  question: "What does the 'M' in SMART goals stand for?",
                  options: [
                    "Monetary",
                    "Manageable",
                    "Measurable",
                    "Meaningful"
                  ],
                  correctAnswerIndex: 2,
                  explanation: "SMART goals should be measurable so you can track progress."
                }
              ]
            },
            order: 4,
            xpReward: 20
          },
          {
            courseId,
            title: "Adjusting Your Budget",
            description: "How to revise and improve your budget",
            content: {
              text: "Regularly review and adjust your budget to better meet your needs and goals.",
              questions: [
                {
                  type: "multiple-choice",
                  question: "How often should you review your budget?",
                  options: [
                    "Once a year",
                    "Once a month",
                    "Only when you get a raise",
                    "Never"
                  ],
                  correctAnswerIndex: 1,
                  explanation: "Monthly reviews help you stay on track and make adjustments."
                }
              ]
            },
            order: 5,
            xpReward: 15
          }
        ];

        for (const lesson of budgetingLessons) {
          await this.createLesson(lesson);
        }
      }
    }
  }
}

export const storage = new DatabaseStorage();